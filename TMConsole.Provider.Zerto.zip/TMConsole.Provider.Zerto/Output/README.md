<!-- region Generated -->
# ZvmRestApi
This directory contains the PowerShell module for the ZvmRestApi service.

---
## Status
[![ZvmRestApi](https://img.shields.io/powershellgallery/v/ZvmRestApi.svg?style=flat-square&label=ZvmRestApi "ZvmRestApi")](https://www.powershellgallery.com/packages/ZvmRestApi/)

## Info
- Modifiable: yes
- Generated: all
- Committed: yes
- Packaged: yes

---
## Detail
This module was primarily generated via [AutoRest](https://github.com/Azure/autorest) using the [PowerShell](https://github.com/Azure/autorest.powershell) extension.

## Development
For information on how to develop for `ZvmRestApi`, see [how-to.md](how-to.md).
<!-- endregion -->
