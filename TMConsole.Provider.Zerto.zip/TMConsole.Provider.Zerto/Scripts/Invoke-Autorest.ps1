# $SwaggerFilePath = "/Users/tbaker/DEV/TDS/tm-powershell-modules/PSModules/TDS Modules/TMConsole.Provider.Zerto/Swagger/openapi-yaml-client-generated/openapi.yaml"
$SwaggerFilePath = "/Users/tbaker/DEV/TDS/tm-powershell-modules/PSModules/TDS Modules/TMConsole.Provider.Zerto/Swagger/openapi-client-generated/openapi.json"


$Arguments = @(
	'--powershell'
	"--input-file=$SwaggerFilePath"
	'--output-folder=Output'
	'--verbose'
	'--clear-output-folder'
)

autorest @Arguments





# ## Script Configuration
# $CreateClientType = [PSCustomObject]@{

# 	## TMD Primary Client Types
# 	PowerShell = $False		## Failed Initial cration is successful, but powershell module build is unsuccessful
# 	TypeScript = $False		## Compiles Successfully, Untested
# 	NodeJS     = $False		## Compiles Successfully, Untested


# 	## Other Client Types
# 	CSharp     = $False		## Failed - likely unmet prerequisites
# 	Go         = $False		## Missing Configuration
# 	Python     = $False		## Compiles Successfully, Untested
# 	AZ         = $False		## Failed check:  https://github.com/Azure/autorest.az/blob/master/doc/01-authoring-azure-cli-commands.md#az-readme-example
# 	Ruby       = $False		## Compiles Successfully, Untested
# 	Php        = $False		## Failed

# }
# $OpenAPISpecFile = ".\api-specs\2021-02-18\openapi-modified.json"


# ## Run Autorest to produce the output files
# Write-Host "Clearing AutoRest Configuration" -ForegroundColor Cyan
# autorest --reset

# ## Select all of the Enabled Client Types
# $EnabledClientConfigs = $CreateClientType.PSObject.Properties.Name | Where-Object {
# 	$Config.CreateClientType.($_)
# }

# ## Use the OpenAPI spec  file to create each client type
# foreach ($ClientType in $EnabledClientConfigs) {

# 	## Convert the Property Name to the proper CLI format
# 	$ClientCliFlag = $ClientType.ToLower()

# 	## Notify the User
# 	Write-Host "Clearing AutoRest Configuration: " -NoNewline
# 	Write-Host $ClientType -ForegroundColor Cyan

# 	## Create the PowerShell Module
# 	autorest --$ClientCliFlag --input-file:$OpenAPISpecFile --output-folder:.\output\$ClientCliFlag  --verbose --clear-output-folder

# 	## Run Post Build Scripts based on Type
# 	if ($ClientType -eq 'PowerShell') {

# 		## Run the PowerShell Generation
# 		. .\output\powershell\build-module.ps1
# 	}
# }