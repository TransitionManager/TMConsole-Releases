﻿
## Add required Class Type Libraries
Add-Type -AssemblyName Microsoft.PowerShell.Commands.Utility


# class ZertoSession {
# 	## A Name parameter to identify the session in other -ZertoSessions functions
# 	[String]$Name

# 	# Zerto Server hostname
# 	[String]$ZertoServer

# 	# Zerto Server hostname
# 	[Int]$ZertoPort

# 	# ZertoVersion drives the selection of compatible APIs to use
# 	[String]$ZertoVersion

# 	# Logged in Zerto User's Context (indicates loggedin-ness)
# 	[PSCustomObject]$UserContext

# 	# ZertoWebSession Variable. Maintained by the Invoke-WebRequest function's capability
# 	$ZertoWebSession

# 	## Tracks non-changing items to reduce HTTP lookups, and increase speed of scripts.
# 	## DataCache is expected to be a k/v pair, where the V could be another k/v pair,
# 	## However, it's implementation will be more of the nature to hold the list of object calls from the API
# 	## like 'credentials' = @(@{...},@{...});  'actions' = @(@{...},@{...})
# 	## Get-Zerto* functions will cache unless a -NoCache switch is provided
# 	[Hashtable]$DataCache

# 	## Should PowerShell ignore the SSL Cert on the Zerto Server?
# 	[Bool]$AllowInsecureSSL

# 	ZertoSession() {
# 		$this.Name = 'Default'
# 		$this.AllowInsecureSSL = $false
# 		$this.DataCache = @{}
# 		$this.UserContext = $null
# 		$this.ZertoPort = 9669
# 		$this.ZertoWebSession = New-Object -Type Microsoft.PowerShell.Commands.WebRequestSession
# 	}

# 	ZertoSession([String]$_name = 'Default') {
# 		$this.Name = $_name
# 		$this.AllowInsecureSSL = $false
# 		$this.DataCache = @{}
# 		$this.UserContext = $null
# 		$this.ZertoPort = 9669
# 		$this.ZertoWebSession = New-Object -Type Microsoft.PowerShell.Commands.WebRequestSession
# 	}

# 	ZertoSession([String]$_name = 'Default', [String]$_server, [Bool]$_allowInsecureSSL = $false) {
# 		$this.Name = $_name
# 		$this.AllowInsecureSSL = $_allowInsecureSSL
# 		$this.ZertoServer = $_server
# 		$this.ZertoPort = 9669
# 		$this.DataCache = @{}
# 		$this.UserContext = $null
# 		$this.ZertoWebSession = New-Object -Type Microsoft.PowerShell.Commands.WebRequestSession
# 	}

# 	ZertoSession([String]$_name = 'Default', [String]$_server, [int]$_port, [Bool]$_allowInsecureSSL = $false) {
# 		$this.Name = $_name
# 		$this.AllowInsecureSSL = $_allowInsecureSSL
# 		$this.ZertoServer = $_server
# 		$this.ZertoPort = $_port
# 		$this.DataCache = @{}
# 		$this.UserContext = $null
# 		$this.ZertoWebSession = New-Object -Type Microsoft.PowerShell.Commands.WebRequestSession
# 	}
# }


## Dot-source the classes
$ClassesFile = Get-Item (Join-Path $PSScriptRoot 'lib' 'Classes' 'Zerto.Classes.ps1')
. $ClassesFile


## Load all files in the lib directory
$LibraryFiles = Get-ChildItem (Join-Path $PSScriptRoot 'lib') -Exclude 'Classes' | Get-ChildItem -Recurse -Force -File

# For Each $Library File, load it
foreach ($LibraryFile in $LibraryFiles) {
    . ($LibraryFile.FullName)
}