Import-Module TMConsole.Provider.Zerto -Force

$ConnectionSplat = @{
	Server           = '10.0.21.15'
	Port             = 9669
	Credential       = Get-StoredCredential '10.0.21.15'
	AllowInsecureSSL = $True
}


New-ZertoSession @ConnectionSplat -Passthru