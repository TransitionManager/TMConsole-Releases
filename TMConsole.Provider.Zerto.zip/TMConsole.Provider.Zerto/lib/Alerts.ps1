
#region Zerto Alerts

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoAlert {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Alert Start Date (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS)')] [string] $StartDate,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Alert End Date (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS)')] [string] $EndDate,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto VPG Identifier')] [string] $VPGIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto ZORG Identifier')] [string] $ZORGIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Site Identifier')] [string] $SiteIdentifier,
        # [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Alert Level')] [ZertoAlertLevel] $Level,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Alert Level')] [PSObject] $Level,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Alert Entity')] [ZertoAlertEntity] $Entity,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Alert HelpIdentifier')] [ZertoAlertHelpIdentifier] $HelpIdentifier,
        [Parameter(Mandatory = $true, ParameterSetName = "ID", HelpMessage = 'Zerto Alert Identifier')] [string] $ZertoAlertIdentifier
    )

	## Get Session Configuration
	$ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
	if (-not $ZertoSessionConfig) {
		Write-Host 'TMSession: [' -NoNewline
		Write-Host $ZertoSession -ForegroundColor Cyan
		Write-Host '] was not Found. Please use the New-ZertoSession command.'
		Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
	}

	#Honor SSL Settings
	if ($ZertoSessionConfig.AllowInsecureSSL) {
		$ZertoCertSettings = @{SkipCertificateCheck = $true }
	}
	else {
		$ZertoCertSettings = @{SkipCertificateCheck = $false }
	}

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"

    switch ($PsCmdlet.ParameterSetName) {
        "ID" {
            if ([string]::IsNullOrEmpty($ZertoAlertIdentifier)  ) {
                throw "Missing Zerto Alert Identifier"
            }

            $FullURL = $baseURL + "alerts/" + $ZertoAlertIdentifier
        }
        Default {
            $FullURL = $baseURL + "alerts"
            if ($StartDate -or $EndDate -or $VPGIdentifier -or $ZORGIdentifier -or $SiteIdentifier -or $Level -ne $null -or $Entity -ne $null -or $HelpIdentifier -ne $null) {
                $qs = [ordered] @{}
                if ($StartDate) { if (Parse-ZertoDate($StartDate)) { $qs.Add("StartDate", $StartDate) } else { throw "Invalid StartDate: '$StartDate'" } }
                if ($EndDate) { if (Parse-ZertoDate($EndDate)) { $qs.Add("EndDate", $EndDate) } else { throw "Invalid EndDate: '$EndDate'" } }
                if ($VPGIdentifier) { $qs.Add("VPGIdentifier", $VPGIdentifier) }
                if ($ZORGIdentifier) { $qs.Add("ZORGIdentifier", $ZORGIdentifier) }
                if ($SiteIdentifier) { $qs.Add("SiteIdentifier", $SiteIdentifier) }
                if ($Level -ne $null) { $qs.Add("Level", $Level) }
                if ($Entity -ne $null) { $qs.Add("Entity", $Entity) }
                if ($HelpIdentifier -ne $null) { $qs.Add("HelpIdentifier", $HelpIdentifier) }

                $FullURL += Get-QueryStringFromHashTable -QueryStringHash $QS
            }
        }
    }
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
function Get-ZertoAlertHelpIdentifierDescription {
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, HelpMessage = 'Zerto Alert HelpIdentifier')] [ZertoAlertHelpIdentifier] $HelpIdentifier
    )
    switch ($HelpIdentifier) {
        AWS0001 { Return "AWS S3 bucket removed" }
        BCK0001 { Return "Offsite backup fails" }
        BCK0002 { Return "Offsite backup fails" }
        BCK0005 { Return "Offsite backup repository disconnected." }
        BCK0006 { Return "Offsite backup repository disconnected." }
        BCK0007 { Return "Offsite backup repository not defined." }
        LIC0001 { Return "License exceeded" }
        LIC0002 { Return "License exceeded" }
        LIC0003 { Return "License about to expire" }
        LIC0004 { Return "License expired and exceeded" }
        LIC0005 { Return "License expired and exceeded" }
        LIC0006 { Return "License expired" }
        LIC0007 { Return "License exceeded" }
        LIC0008 { Return "License exceeded" }
        STR0001 { Return "Datastore not accessible" }
        STR0002 { Return "Datastore full" }
        STR0004 { Return "Datastore low in space" }
        VCD0001 { Return "vCenter Server for the Org vDC is not found" }
        VCD0002 { Return "Org vDC is defined in multiple vCenter Servers" }
        VCD0003 { Return "Org vDC storage profile not found in vCenter Server" }
        VCD0004 { Return "Provider vDC storage profile not found in vCenter Server" }
        VCD0005 { Return "Org vDC network not retrieved" }
        VCD0006 { Return "Provider vDC metadata not found" }
        VCD0007 { Return "Org vDC resource pool not retrieved" }
        VCD0010 { Return "OrgNetwork not retrieved" }
        VCD0014 { Return "vCD disconnection" }
        VCD0015 { Return "AMQP-server disconnection" }
        VCD0016 { Return "Provider vDC datastore not found" }
        VCD0017 { Return "Metadata not accessible" }
        VCD0018 { Return "Duplicated MAC addresses" }
        VCD0020 { Return "VM inconsistency in vApp" }
        VCD0021 { Return "VM inconsistency in vApp" }
        VPG0003 { Return "VPG has low journal history" }
        VPG0004 { Return "VPG has low journal history" }
        VPG0005 { Return "VPG in error state" }
        VPG0006 { Return "VPG missing configuration details" }
        VPG0007 { Return "VPG replication paused" }
        VPG0008 { Return "VPG rollback failed" }
        VPG0009 { Return "VPG target RPO exceeded" }
        VPG0010 { Return "VPG target RPO exceeded" }
        VPG0011 { Return "VPG test overdue" }
        VPG0012 { Return "VPG test overdue" }
        VPG0014 { Return "VPG waiting for commit or rollback" }
        VPG0015 { Return "Resources not enough to support VPG" }
        VPG0016 { Return "Resources pool not found" }
        VPG0017 { Return "VPG protection paused" }
        VPG0018 { Return "VMs in VPG not configured with a storage profile" }
        VPG0019 { Return "VPG recovery storage profile disabled" }
        VPG0020 { Return "VPG recovery storage profile not found" }
        VPG0021 { Return "VPG recovery storage profile not found" }
        VPG0022 { Return "VPG recovery storage profile disabled" }
        VPG0023 { Return "VPG recovery storage profile not found" }
        VPG0024 { Return "VPG recovery storage profile does not include active datastores" }
        VPG0025 { Return "vApp network mapping not defined" }
        VPG0026 { Return "VPG recovery storage profile changed" }
        VPG0027 { Return "VPG includes VMs that are no longer protected" }
        VPG0028 { Return "Corrupted Org vDC network mapping" }
        VPG0035 { Return "VPG protected resources not in ZORG" }
        VPG0036 { Return "VPG recovery resources not in ZORG" }
        VPG0037 { Return "Journal history is compromised" }
        VPG0038 { Return "Journal history is compromised" }
        VPG0039 { Return "RDM has an odd number of blocks" }
        VPG0040 { Return "Virtual machine hardware mismatch with recovery site" }
        VPG0041 { Return "Virtual machine running Windows 2003" }
        VPG0042 { Return "Recovery network not found" }
        VPG0043 { Return "Cross-replication: warning" }
        VPG0044 { Return "Cross-replication: error" }
        VPG0045 { Return "VPG has low journal history: warning" }
        VPG0046 { Return "VPG has low journal history: error" }
        VPG0047 { Return "Journal history is compromised: warning" }
        VPG0048 { Return "Journal history is compromised: error" }
        VRA0001 { Return "Host without VRA" }
        VRA0002 { Return "VRA without IP" }
        VRA0003 { Return "Host IP changes" }
        VRA0004 { Return "VRA lost IP" }
        VRA0005 { Return "VRAs not connected" }
        VRA0006 { Return "Datastore for journal disk is full" }
        VRA0007 { Return "I/O error to journal" }
        VRA0008 { Return "Recovery disk and VMs missing" }
        VRA0009 { Return "Recovery disk missing" }
        VRA0010 { Return "Recovery disks turned off" }
        VRA0011 { Return "Recovery disk inaccessible" }
        VRA0012 { Return "Cannot write to recovery disk" }
        VRA0013 { Return "I/O error to recovery disk" }
        VRA0014 { Return "Cloned disks turned off" }
        VRA0015 { Return "Cloned disk inaccessible" }
        VRA0016 { Return "Datastore for clone disk is full" }
        VRA0017 { Return "I/O error to clone" }
        VRA0018 { Return "Protected disk and VM missing" }
        VRA0019 { Return "Protected disk missing" }
        VRA0020 { Return "VM powered off" }
        VRA0021 { Return "VM disk inaccessible" }
        VRA0022 { Return "VM disk incompatible" }
        VRA0023 { Return "VRA cannot be registered." }
        VRA0024 { Return "VRA removed" }
        VRA0025 { Return "I/O synchronization" }
        VRA0026 { Return "Recovery disk removed" }
        VRA0027 { Return "Journal disk removed" }
        VRA0028 { Return "VRA powered off" }
        VRA0029 { Return "VRA memory low" }
        VRA0030 { Return "Journal size mismatch" }
        VRA0032 { Return "VRA out-of-date" }
        VRA0035 { Return "VRA reconciliation" }
        VRA0036 { Return "For internal use only" }
        VRA0037 { Return "Local MAC Address Conflict" }
        VRA0038 { Return "MAC Address Conflict" }
        VRA0039 { Return "Journal reached configured limit" }
        VRA0040 { Return "Journal space low" }
        VRA0049 { Return "Host rollback failed" }
        VRA0050 { Return "Wrong host password" }
        VRA0051 { Return "For internal use only" }
        VRA0052 { Return "Disk visible but not recognized" }
        VRA0053 { Return "System disk removed" }
        VRA0054 { Return "" }
        VRA0055 { Return "" }
        ZCC0001 { Return "Zerto Cloud Connector removed" }
        ZCC0002 { Return "Zerto Cloud Connector powered off" }
        ZCC0003 { Return "Orphaned Zerto Cloud Connector" }
        ZCM0001 { Return "No connection to Zerto Virtual Manager" }
        ZVM0001 { Return "No connection to hypervisor manager, such as VMware vCenter Server and Microsoft SCVMM" }
        ZVM0002 { Return "No connection to VRA" }
        ZVM0003 { Return "No connection to site" }
        ZVM0004 { Return "Peer site out-of-date" }
        ZVM0005 { Return "Zerto Virtual Manager space low" }
        ZVM0006 { Return "Upgrade available" }
        ZVM0007 { Return "Cannot upgrade" }
        ZVM0008 { Return "Version mismatch" }
        ZVM0009 { Return "Internal error" }
        ZVM0010 { Return "Synchronization between Zerto Virtual Managers" }
        ZVM0011 { Return "Metadata collection" }
        ZVM0012 { Return "Metadata collection" }
        ZVM0013 { Return "Metadata collection" }
        ZVM0014 { Return "SCSI not found" }
        ZVM0015 { Return "Hyper-V host not accessible" }
        FLR0001 { Return "Files cannot be restored" }
        Unknown { Return "Unknown" }


    }
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Invoke-ZertoAlertDismiss {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Alert Identifier')] [string] $ZertoAlertIdentifier
   )

	## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"

       if ([string]::IsNullOrEmpty($ZertoAlertIdentifier)  ) {
        throw "Missing Zerto Alert Identifier"
    }

    $FullURL = $baseURL + "alerts/" + $ZertoAlertIdentifier + "/dismiss"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Post
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Invoke-ZertoAlertUndismiss {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Alert Identifier')] [string] $ZertoAlertIdentifier
   )

	## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"

       if ([string]::IsNullOrEmpty($ZertoAlertIdentifier)  ) {
        throw "Missing Zerto Alert Identifier"
    }

    $FullURL = $baseURL + "alerts/" + $ZertoAlertIdentifier + "/undismiss"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Post
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoAlertEntity {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default"
   )

	## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"



    $FullURL = $baseURL + "alerts/entities"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoAlertHelpIdentifier {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default"
   )

	## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"



    $FullURL = $baseURL + "alerts/helpidentifiers"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoAlertLevel {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default"
   )

	## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"



    $FullURL = $baseURL + "alerts/levels"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}
#endregion