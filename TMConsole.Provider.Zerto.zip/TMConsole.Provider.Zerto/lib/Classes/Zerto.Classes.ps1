# Load the classes in a specific order
@(
	'ZertoSession'
	'ZertoEnums'
	# 'ZertoReference', # ZertoReference always needs to go first because it is referenced by other classes
	# 'ZertoSetting',
	# 'ZertoAssetOption',
	# 'ZertoEvent',
	# 'ZertoProfile',
	# 'ZertoTag',
	# 'ZertoTask',
	# 'ZertoTeam'
) | ForEach-Object {
	. "$(Join-Path $PSSCriptRoot 'Public' ($_ + '.ps1'))"
}