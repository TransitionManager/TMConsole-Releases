
#region Zerto Events

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoEvent {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Event Start Date (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS)')] [string] $StartDate,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Event End Date (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS)')] [string] $EndDate,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto VPG Identifier')] [string] $VPGIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Alert Entity')] [ZertoEventType] $EventType,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Site Name')] [string] $SiteName,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Site Identifier')] [string] $SiteIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto ZORG Identifier')] [ZertoEventType] $ZORGIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Alert Entity Type')] [ZertoAlertEntity] $EntityType,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto User Name')] [string] $UserName,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Event Category')] [ZertoEventCategory] $EventCategory,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Alert Identifier')] [string] $ZertoAlertIdentifier,
        [Parameter(Mandatory = $true, ParameterSetName = "ID", HelpMessage = 'Zerto Event Identifier')] [string] $ZertoEventIdentifier
   )

	## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"



    switch ($PsCmdlet.ParameterSetName) {
        "ID" {
            if ([string]::IsNullOrEmpty($ZertoEventIdentifier)  ) {
                throw "Missing Zerto Event Identifier"
            }

            $FullURL = $baseURL + "events/" + $ZertoEventIdentifier
        }
        Default {
            $FullURL = $baseURL + "events"
            if ($StartDate -or $EndDate -or $VPGIdentifier -or $EventType -ne $null -or $SiteName -or $SiteIdentifier -or $ZORGIdentifier `
                    -or $EntityType -ne $null -or $UserName -or $EventCategory -ne $null -or $ZertoAlertIdentifier) {
                $qs = [ordered] @{}
                if ($StartDate) { if (Parse-ZertoDate($StartDate)) { $qs.Add("StartDate", $StartDate) } else { throw "Invalid StartDate: '$StartDate'" } }
                if ($EndDate) { if (Parse-ZertoDate($EndDate)) { $qs.Add("EndDate", $EndDate) } else { throw "Invalid EndDate: '$EndDate'" } }
                if ($VPGIdentifier) { $qs.Add("VPGIdentifier", $VPGIdentifier) }
                if ($EventType -ne $null) { $qs.Add("EventType", $EventType) }
                if ($SiteName) { $qs.Add("siteName", $SiteName) }
                if ($SiteIdentifier) { $qs.Add("SiteIdentifier", $SiteIdentifier) }
                if ($EntityType -ne $null) { $qs.Add("EntityType", $EntityType) }
                if ($ZORGIdentifier) { $qs.Add("ZORGIdentifier", $ZORGIdentifier) }
                if ($UserName) { $qs.Add("UserName", $UserName) }
                if ($EventCategory -ne $null) { $qs.Add("EventCategory", $EventCategory) }
                if ($ZertoAlertIdentifier) { $qs.Add("ZertoAlertIdentifier", $ZertoAlertIdentifier) }

                $FullURL += Get-QueryStringFromHashTable -QueryStringHash $QS
            }
        }
    }
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoEventCategory {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default"
   )

	## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"



    $FullURL = $baseURL + "events/categories"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoEventEntity {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default"
   )

	## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"



    $FullURL = $baseURL + "Events/entities"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoEventType {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default"
   )

	## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"



    $FullURL = $baseURL + "events/types"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}
#endregion