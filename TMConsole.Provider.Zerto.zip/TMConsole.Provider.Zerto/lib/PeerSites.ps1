
#region Zerto Peer Sites

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoPeerSite {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Peer Site name')] [string] $PeerName,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Peer Site pairing status')] [ZertoPairingStatus] $ParingStatus,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Peer Site location')] [string] $Location,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Peer Site host name')] [string] $HostName,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Peer Site port')] [string] $Port,
        [Parameter(Mandatory = $true, ParameterSetName = "ID", HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier
   )

	## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"



    switch ($PsCmdlet.ParameterSetName) {
        "ID" {
            if ([string]::IsNullOrEmpty($ZertoSiteIdentifier)  ) {
                throw "Missing Zerto Site Identifier"
            }

            $FullURL = $baseURL + "peersites/" + $ZertoSiteIdentifier
        }
        Default {
            $FullURL = $baseURL + "peersites"
            if ($PeerName -or $ParingStatus -ne $null -or $Location -or $HostName -or $Port) {
                $qs = [ordered] @{}
                if ($PeerName) { $qs.Add("peerName", $PeerName) }
                if ($ParingStatus -ne $null) { $qs.Add("paringStatus", $ParingStatus) }
                if ($Location) { $qs.Add("location", $Location) }
                if ($HostName) { $qs.Add("hostName", $HostName) }
                if ($Port) { $qs.Add("port", $Port) }

                $FullURL += Get-QueryStringFromHashTable -QueryStringHash $QS
            }
        }
    }
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoPeerSiteID {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto PeerSite Name')] [string] $ZertoPeerSiteName
    )

    $ID = Get-ZertoPeerSite -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken | `
        Where-Object { $_.PeerSiteName -eq $ZertoPeerSiteName } | `
        Select-Object SiteIdentifier -ExpandProperty SiteIdentifier

    if ($ID.Count -gt 1) { Throw "'$ZertoPeerSiteName' returned more than one ID" }
    if ($ID.Count -eq 0) { Throw "'$ZertoPeerSiteName' was not found" }

    return $ID.ToString()
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Connect-ZertoPeerSite {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, ParameterSetName = "Post", HelpMessage = 'Address or DNS name of new site')] [string] $HostName,
        [Parameter(Mandatory = $false, ParameterSetName = "Post", HelpMessage = 'The default port used for communication between paired Zerto Virtual Managers. The default port is 9081.')] [int] $Port = 9081
        , [Parameter(Mandatory = $false, HelpMessage = 'Dump Json without posting for debug')] [switch] $DumpJson
   )

	## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"


       if ( $HostName -eq $null) {
        throw "Missing new site HostName"
    }
    if ( $Port -eq $null) {
        throw "Missing new site Port"
    }
    If (-Not (Test-Connection $HostName -Count 1 -Quiet) ) {
        throw "Could not ping '$hostname'"
    }
    $testport = 0
    If ( -Not ([int]::TryParse($port, [ref] $testport) ) ) {
        throw "Invaild port '$port'. Must be a postive integer."
    }
    If ( ($port -le 0) -or ($Port -gt [math]::Pow(2, 16) )  ) {
        throw ("Invaild port '$port'. Must be > 0 and < " + ([math]::Pow(2, 16)))
    }

    $FullURL = $baseURL + "peersites"
    Write-Verbose $FullURL

    $BodyHash = [ordered] @{}
    $BodyHash.Add("HostName", $HostName)
    $BodyHash.Add("Port", $Port)
    $BodyJson = $BodyHash | ConvertTo-Json -Depth 20

    if ($DumpJson ) {
        #Display JSON, and exit
        Write-Host $BodyJson
        return
    }

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Post -Body $BodyJson
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Disconnect-ZertoPeerSite {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier of Peersite to disconnect')] [string] $ZertoSiteIdentifier,
        [Parameter(Mandatory = $false, HelpMessage = 'Keep Target Disks in Peer site')] [boolean] $KeepTargetDisks = $false
        , [Parameter(Mandatory = $false, HelpMessage = 'Dump Json without posting for debug')] [switch] $DumpJson
   )

	## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"


       if ([string]::IsNullOrEmpty($ZertoSiteIdentifier)  ) {
        throw "Missing Zerto Site Identifier"
    }

    $FullURL = $baseURL + "peersites/" + $ZertoSiteIdentifier
    Write-Verbose $FullURL

    $BodyHash = [ordered] @{}
    $BodyHash.Add("IsKeepTargetDisks", $KeepTargetDisks)
    $BodyJson = $BodyHash | ConvertTo-Json -Depth 20

    if ($DumpJson ) {
        #Display JSON, and exit
        Write-Host $BodyJson
        return
    }

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Delete -Body $BodyJson
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}


#endregion