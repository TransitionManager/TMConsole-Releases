#region Zerto Resoure Report

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoResouresReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Report From Time (YYYY-MM-DD HH:MM:SS)')] [string] $FromTime,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Report To Time (YYYY-MM-DD HH:MM:SS)')] [string] $ToTime,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Report Start Index ')] [string] $StartIndex,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Report Records to retrieve 1 to 500')] [string] $Count = 500
    )

    $baseURL = "https://" + $ZertoServer + ":" + $ZertoPort + "/ZvmService/ResourcesReport/"
    $TypeJSON = "application/json"


    if ($Count -lt 1 -or $Count -gt 500) {
        throw "Invalid Count - must be from 1 to 500"
    }

    $FullURL = $baseURL + "getSamples"
    if ($FromTime -or $ToTime -or $StartIndex -or $Count ) {
        $qs = [ordered] @{}
        if ($FromTime) { if (Parse-ZertoDate($FromTime)) { $qs.Add("fromTimeString", $FromTime) } else { throw "Invalid FromTime: '$FromTime'" } }
        if ($ToTime) { if (Parse-ZertoDate($ToTime)) { $qs.Add("toTimeString", $ToTime) } else { throw "Invalid ToTime: '$ToTime'" } }
        if ($StartIndex) { $qs.Add("startIndex", $StartIndex) }
        if ($Count) { $qs.Add("count", $Count) }
        $FullURL += Get-QueryStringFromHashTable -QueryStringHash $QS
    }
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoResourcesReportAdvFilter {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Report From Time (YYYY-MM-DD HH:MM:SS)')] [string] $FromTime,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Report To Time (YYYY-MM-DD HH:MM:SS)')] [string] $ToTime,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Report Start Index ')] [string] $StartIndex,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Report Records to Retrieve 1 to 500')] [string] $Count,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Report Records Advanced Filter')] [string] $Filter
    )

    $baseURL = "https://" + $ZertoServer + ":" + $ZertoPort + "/ZvmService/ResourcesReport/"
    $TypeJSON = "application/json"


    $FullURL = $baseURL + "getSamples"
    if ($FromTime -or $ToTime -or $StartIndex -or $Count -or $Filter ) {
        $qs = [ordered] @{}
        if ($FromTime) { if (Parse-ZertoDate($FromTime)) { $qs.Add("fromTimeString", $FromTime) } else { throw "Invalid FromTime: '$FromTime'" } }
        if ($ToTime) { if (Parse-ZertoDate($ToTime)) { $qs.Add("toTimeString", $ToTime) } else { throw "Invalid ToTime: '$ToTime'" } }
        if ($StartIndex) { $qs.Add("startIndex", $StartIndex) }
        if ($Count) { $qs.Add("count", $Count) }
        if ($Filter) { $qs.Add("Filter", $Filter) }
        $FullURL += Get-QueryStringFromHashTable -QueryStringHash $QS
    }
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}
#endregion
