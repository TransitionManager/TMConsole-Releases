
#region Zerto Service Profiles
# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoServiceProfile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier,
        [Parameter(Mandatory = $true, ParameterSetName = "ID", HelpMessage = 'Zerto Service Profile Identifier')] [string] $ZertoServiceProfileIdentifier
   )

	## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"



    switch ($PsCmdlet.ParameterSetName) {
        "ID" {
            if ([string]::IsNullOrEmpty($ZertoServiceProfileIdentifier)  ) {
                throw "Missing Zerto Service Profile Identifier"
            }
            $FullURL = $baseURL + "serviceprofiles/" + $ZertoServiceProfileIdentifier
        }
        Default {
            $FullURL = $baseURL + "serviceprofiles"
            if ($ZertoSiteIdentifier) {
                $qs = [ordered] @{}
                if ($SiteIdentifier) { $qs.Add("Site", $ZertoSiteIdentifier) }

                $FullURL += Get-QueryStringFromHashTable -QueryStringHash $QS
            }
        }
    }
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoServiceProfileID {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Site Identifier')] [string] $SiteIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Service Profile Name')] [string] $ZertoServiceProfileName
    )

    $ID = Get-ZertoServiceProfile -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken -SiteIdentifier $SiteIdentifier | `
        Where-Object { $_.ServiceProfileName -eq $ZertoServiceProfileName } | `
        Select-Object ServiceProfileIdentifier -ExpandProperty ServiceProfileIdentifier

    if ($ID.Count -gt 1) { Throw "'$ZertoServiceProfileName' returned more than one ID" }
    if ($ID.Count -eq 0) { Throw "'$ZertoServiceProfileName' was not found" }

    return $ID.ToString()
}
#endregion
