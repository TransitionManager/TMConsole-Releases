
#region Zerto VPGs

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPG {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $false, ParameterSetName = 'Filter', HelpMessage = 'Zerto VPG Name')] [string] $VPGName,
        [Parameter(Mandatory = $false, ParameterSetName = 'Filter', HelpMessage = 'Zerto VPG Status')] [ZertoVPGStatus] $Status,
        [Parameter(Mandatory = $false, ParameterSetName = 'Filter', HelpMessage = 'Zerto VPG Status')] [ZertoVPGSubStatus] $SubStatus,
        [Parameter(Mandatory = $false, ParameterSetName = 'Filter', HelpMessage = 'Zerto Protected Site Type')] [ZertoProtectedSiteType] $ProtectedSiteType,
        [Parameter(Mandatory = $false, ParameterSetName = 'Filter', HelpMessage = 'Zerto Recovery Site Type')] [ZertoRecoverySiteType] $RecoverySiteType,
        [Parameter(Mandatory = $false, ParameterSetName = 'Filter', HelpMessage = 'Zerto Protected Site Identifier')] [string] $ProtectedSiteIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = 'Filter', HelpMessage = 'Zerto Recovery Site Identifier')] [string] $RecoverySiteIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = 'Filter', HelpMessage = 'Zerto ZOrg Name')] [string] $ZOrganizationName,
        [Parameter(Mandatory = $false, ParameterSetName = 'Filter', HelpMessage = 'Zerto ZOrg Identifier')] [string] $ZOrgIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = 'Filter', HelpMessage = 'Zerto VPG Priority')] [string] $Priority,
        [Parameter(Mandatory = $false, ParameterSetName = 'Filter', HelpMessage = 'Zerto Service Profile Identifier')] [string] $ServiceProfileIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = 'Filter', HelpMessage = 'Zerto VPG Backup Enabled ')] [boolean] $BackupEnabled,
        [Parameter(Mandatory = $true, ParameterSetName = 'ID', HelpMessage = 'Zerto VPG Identifier')] [string] $ZertoVpgIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'



    switch ($PsCmdlet.ParameterSetName) {
        'ID' {
            if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
                throw 'Missing Zerto VPG Identifier'
            }

            $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier
        }
        Default {
            $FullURL = $baseURL + 'vpgs'
            if ($VPGName -or $Status -ne $null -or $SubStatus -ne $null -or $ProtectedSiteType -ne $null `
                    -or $RecoverySiteType -ne $null -or $ProtectedSiteIdentifier -or `
                    $RecoverySiteIdentifier -or $ZOrganizationName -or $ZOrgIdentifier `
                    -or $priority -ne $null -or $serviceProfileIdentifier -or $backupEnabled ) {
                $qs = [ordered] @{}
                if ($VPGName) { $qs.Add('Name', $VPGName) }
                if ($Status -ne $null) { $qs.Add('Status', $Status) }
                if ($SubStatus -ne $null) { $qs.Add('SubStatus', $SubStatus) }
                if ($ProtectedSiteType -ne $null) { $qs.Add('ProtectedSiteType', $ProtectedSiteType) }
                if ($RecoverySiteType -ne $null) { $qs.Add('RecoverySiteType', $RecoverySiteType) }
                if ($ProtectedSiteIdentifier) { $qs.Add('ProtectedSiteIdentifier', $ProtectedSiteIdentifier) }
                if ($RecoverySiteIdentifier) { $qs.Add('RecoverySiteIdentifier', $RecoverySiteIdentifier) }
                if ($ZOrganizationName) { $qs.Add('ZOrganizationName', $ZOrganizationName) }
                if ($ZOrgIdentifier) { $qs.Add('ZOrgIdentifier', $ZOrgIdentifier) }
                if ($Priority -ne $null) { $qs.Add('priority', $Priority) }
                if ($ServiceProfileIdentifier) { $qs.Add('ServiceProfileIdentifier', $ServiceProfileIdentifier) }
                if ($BackupEnabled) { $qs.Add('BackupEnabled', $BackupEnabled) }

                # $FullURL += Get-QueryStringFromHashTable -QueryStringHash $QS
            }
        }
    }
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Convert-ZertoVPGToVPGSetting {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Identifier')] [string] $ZertoVpgIdentifier
        , [Parameter(Mandatory = $false, HelpMessage = 'Dump Json without posting for debug')] [switch] $DumpJson
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
        throw 'Missing Zerto VPG Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings'
    Write-Verbose $FullURL

    $BodyHash = @{}
    $BodyHash.Add('VpgIdentifier', $ZertoVpgIdentifier )
    $BodyJson = $BodyHash | ConvertTo-Json
    Write-Verbose $BodyJson
    if ($DumpJson ) {
        #Display JSON, and exit
        Write-Host $BodyJson
        return
    }

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Body $BodyJson -Method Post
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGID {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Name')] [string] $VpgName
    )

    $ID = Get-ZertoVPG -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken | `
            Where-Object { $_.VpgName -eq $VpgName } | `
            Select-Object VpgIdentifier -ExpandProperty VpgIdentifier

    if ($ID.Count -gt 1) { Throw "'$VpgName' returned more than one ID" }
    if ($ID.Count -eq 0) { Throw "'$VpgName' was not found" }

    return $ID.ToString()
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGCheckpoint {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Identifier')] [string] $ZertoVpgIdentifier,
        [Parameter(Mandatory = $True, ParameterSetName = 'ID', HelpMessage = 'Zerto VPG Checkpoint Identifier')] [string] $ZertoVpgCheckpointIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = 'Filter', HelpMessage = 'Zerto Checkpoint Start Date (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS)')] [string] $StartDate,
        [Parameter(Mandatory = $false, ParameterSetName = 'Filter', HelpMessage = 'Zerto Checkpoint End Date (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS)')] [string] $EndDate
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
        throw 'Missing Zerto VPG Identifier'
    }

    switch ($PsCmdlet.ParameterSetName) {
        'ID' {
            if ([string]::IsNullOrEmpty($ZertoVpgCheckpointIdentifier)  ) {
                throw 'Missing Zerto VPG Checkpoint Identifier'
            }
            $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier + '/checkpoints'
        }
        Default {
            $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier + '/checkpoints'

            if ($StartDate -or $EndDate ) {
                $qs = [ordered] @{}
                if ($StartDate) { if (Parse-ZertoDate($StartDate)) { $qs.Add('StartDate', $StartDate) } else { throw "Invalid StartDate: '$StartDate'" } }
                if ($EndDate) { if (Parse-ZertoDate($EndDate)) { $qs.Add('EndDate', $EndDate) } else { throw "Invalid EndDate: '$EndDate'" } }
                $FullURL += Get-QueryStringFromHashTable -QueryStringHash $QS
            }
        }
    }
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }

    #Filter by ID if needed
    switch ($PsCmdlet.ParameterSetName) {
        'ID' {
            $Result = $Result | Where-Object { $_.CheckpointIdentifier -eq $ZertoVpgCheckpointIdentifier }
        }
        Default {
        }
    }

    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGCheckpointID {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Identifier')] [string] $ZertoVpgIdentifier,
        [Parameter(Mandatory = $true, ParameterSetName = 'Tag', HelpMessage = 'Zerto Checkpoint Tag')] [string] $ZertoVpgCheckpointTag
    )

    #if ($ZertoVpgCheckpointIdentifier) {
    #    $ID =  Get-ZertoVPGCheckpoint -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken -ZertoVpgIdentifier $ZertoVpgIdentifier | `
    #                        Where-Object {$_.CheckpointIdentifier -eq $ZertoVpgCheckpointIdentifier} | `
    #                        Select-Object CheckpointIdentifier -ExpandProperty CheckpointIdentifier
    #} elseif ($ZertoVpgCheckpointTag) {
    #    $ID =  Get-ZertoVPGCheckpoint -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken -ZertoVpgIdentifier $ZertoVpgIdentifier | `
    #                        Where-Object {$_.Tag -eq $ZertoVpgCheckpointTag} | `
    #                        Select-Object CheckpointIdentifier -ExpandProperty CheckpointIdentifier
    #}

    $ID = Get-ZertoVPGCheckpoint -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken -ZertoVpgIdentifier $ZertoVpgIdentifier | `
            Where-Object { $_.Tag -eq $ZertoVpgCheckpointTag } | `
            Select-Object CheckpointIdentifier -ExpandProperty CheckpointIdentifier

    if ($ID.Count -gt 1) { Throw "'$ZertoVpgCheckpointTag' returned more than one ID" }
    if ($ID.Count -eq 0) { Throw "'$ZertoVpgCheckpointTag' was not found" }

    return $ID.ToString()
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGCheckpointLastID {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Identifier')] [string] $ZertoVpgIdentifier
    )

    $ID = (Get-ZertoVPGCheckpoint -ZertoVpgIdentifier $ZertoVpgIdentifier)[-1] |
        Select-Object CheckpointIdentifier -ExpandProperty CheckpointIdentifier

    return $ID.ToString()
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGCheckpointSummary {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Identifier')] [string] $ZertoVpgIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
        throw 'Missing Zerto VPG Identifier'
    }

    $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier + '/checkpoints/Summary'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    #Show depricated if 5.0u2 or higher
    try {
        switch ( [Version] $env:ZertoVersion) {
            { $_ -ge [Version]::new('5.0.21') }     #5.0u2
            { Write-Warning 'Get-ZertoVPGCheckpointSummary is depricated as of Zerto 5.0u2.  Use Get-Get-ZertoVPGCheckpointStats.' }
            5.0.12 {  }   #5.0u1
            Default {}
        }
    } catch {
        Write-Warning "Invalid ZertoVersion: $env:ZertoVersion "
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGCheckpointStats {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Identifier')] [string] $ZertoVpgIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
        throw 'Missing Zerto VPG Identifier'
    }

    $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier + '/checkpoints/stats'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGEntityType {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default'
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    $FullURL = $baseURL + 'vpgs/entitytypes'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGFailoverCommitPolicy {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default'
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    $FullURL = $baseURL + 'vpgs/failovercommitpolicies'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGFailoverShutdownPolicy {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default'
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    $FullURL = $baseURL + 'vpgs/failovershutdownpolicies'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGPriority {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default'
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    $FullURL = $baseURL + 'vpgs/priorities'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGRetentionPolicy {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default'
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    $FullURL = $baseURL + 'vpgs/retentionpolicies'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGStatus {
    [CmdletBinding(DefaultParameterSetName = 'Default')]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, ParameterSetName = 'Status', HelpMessage = 'Zerto VPG Status')] [string] $ZertoVPGStatus,
        [Parameter(Mandatory = $true, ParameterSetName = 'ID', HelpMessage = 'Zerto VPG Status ID')] [ZertoVPGStatus] $ZertoVPGStatusID
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-ZertoSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'



    switch ($PsCmdlet.ParameterSetName) {
        'Status' {
            if ([string]::IsNullOrEmpty($ZertoVPGStatus)  ) {
                throw 'Missing Zerto VPG Status'
            }
            Return [ZertoVPGStatus]::$ZertoVPGStatus.value__
        }
        'ID' {
            Return [ZertoVPGStatus]$ZertoVPGStatusID
        }
        Default {
            #return [System.Enum]::GetNames([ZertoVPGStatus])
            $FullURL = $baseURL + 'vpgs/statuses'
            Write-Verbose $FullURL

            try {
                $RestMethodSplat = @{
                    Uri         = $FullURL
                    TimeoutSec  = 100
                    ContentType = $TypeJSON
                    Method      = 'GET'
                    WebSession  = $ZertoSessionConfig.ZertoWebSession
                }
                $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
            } catch {
                throw $_.Exception.Message
            }
            return $Result
        }
    }
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGSubstatus {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default'
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    $FullURL = $baseURL + 'vpgs/substatuses'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Add-ZertoVPG {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Name')] [string] $VPGName,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto VPG Priority')] [ZertoVPGPriority] $Priority = 'Medium',
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto VPG Type')] [ZertoVPGType] $VpgType = 'Remote',
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Recovery Site Name' )] [string] $RecoverySiteName,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Recovery Site Id')] [string] $RecoverySiteId,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto RPO Alert in seconds')] [ValidateRange(0, 99999)]  [int] $RPOAlertInSeconds = 300,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Test Interval in minutes')] [ValidateRange(0, 9999999)] [int] $TestIntervalInMinutes = 262080,
        [Parameter(Mandatory = $false, HelpMessage = 'Host Cluster Name')] [string] $ClusterName,
        [Parameter(Mandatory = $false, HelpMessage = 'Host Name')] [string] $HostName,
        [Parameter(Mandatory = $false, HelpMessage = 'Failover Network')] [string] $FailoverNetwork,
        [Parameter(Mandatory = $false, HelpMessage = 'Failover Network ID')] [string] $FailoverNetworkID,
        [Parameter(Mandatory = $false, HelpMessage = 'Test Network')] [string] $TestNetwork,
        [Parameter(Mandatory = $false, HelpMessage = 'Test Network ID')] [string] $TestNetworkID,
        [Parameter(Mandatory = $false, HelpMessage = 'Datastore Name')] [string] $DatastoreName,
        [Parameter(Mandatory = $false, HelpMessage = 'Datastore Cluster Name')] [string] $DatastoreClusterName,
        [Parameter(Mandatory = $false, HelpMessage = 'ResourcePool Name')] [string] $ResourcePoolName,
        [Parameter(Mandatory = $false, HelpMessage = 'Use Default for Journal Datastore')] [switch] $JournalUseDefault,
        [Parameter(Mandatory = $false, HelpMessage = 'Journal Datastore Name')] [string] $JournalDatastoreName,
        [Parameter(Mandatory = $false, HelpMessage = 'Journal Datastore Cluster Name')] [string] $JournalDatastoreClusterName,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Journal History In Hours')] [ValidateRange(0, 9999)] [int] $JournalHistoryInHours = 24,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Journal Hard Limit in MB')] [ValidateRange(0, 9999999)] [int] $JournalHardLimitMB = 153600,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Journal Warning Threshold in MB')] [ValidateRange(0, 9999999)] [int] $JournalWarningThresholdMB = 115200,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto vCenter Folder')] [string] $Folder,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto vCenter Folder ID')] [string] $FolderID,

        [Parameter(Mandatory = $true, ParameterSetName = 'VMNames', HelpMessage = 'Zerto Virtual Machine names')] [string[]] $VmNames,
        [Parameter(Mandatory = $true, ParameterSetName = 'VMClass', HelpMessage = 'Zerto VPG Virtual Machine class')] [VPGVirtualMachine[]] $VPGVirtualMachines

        , [Parameter(Mandatory = $false, HelpMessage = 'Commit this Zerto VPG')] [bool] $VPGCommit = $true
        , [Parameter(Mandatory = $false, HelpMessage = 'Dump Json without posting for debug')] [switch] $DumpJson
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($VPGName)  ) { throw 'Missing Zerto VPG Name' }
    if ([string]::IsNullOrEmpty($Priority)  ) { throw 'Missing Zerto Priority' }

    #Validate Parameter Sets
    if ($FailoverNetwork -and $FailoverNetworkID) { throw 'Cannot specify both Failover Network and Failover Network ID' }
    if (-not $FailoverNetwork -and -not $FailoverNetworkID) { throw 'Must specify either Failover Network or Failover Network ID' }

    if ($TestNetwork -and $TestNetworkID) { throw 'Cannot specify both Test Network and Test Network ID' }
    if (-not $TestNetwork -and -not $TestNetworkID) { throw 'Must specify either Test Network or Test Network ID' }

    if ($HostName -and $ClusterName) { throw 'Cannot specify both Host Name and Cluster Name' }
    if (-not $HostName -and -not $ClusterName) { throw 'Must specify either Host Name or Cluster Name' }

    if ($DatastoreName -and $DatastoreClusterName) { throw 'Cannot specify both Datastore Name and Datastore Cluster Name' }
    if (-not $DatastoreName -and -not $DatastoreclusterName) { throw 'Must specify either Datastore Name or Datastore Cluster Name' }

    if ($JournalUseDefault -and ($JournalDatastoreName -OR $JournalDatastoreclusterName ) ) { throw 'Cannot specify JournalUseDefault and JournalDatastoreName or JournalDatastoreClusterName' }
    if ((-not $JournalUseDefault ) -and ($JournalDatastoreName -AND $JournalDatastoreclusterName) ) { throw 'Cannot specify both JournalDatastoreName and JournalDatastoreClusterName' }
    if ((-not $JournalUseDefault ) -and (-not $JournalDatastoreName -and -not $JournalDatastoreclusterName)) { throw 'Must specify either Journal Datastore Name or Journal Datastore Cluster Name' }

    if ($Folder -and $FolderID) { throw 'Cannot specify both Folder and Folder ID' }
    if (-not $Folder -and -not $FolderID) { throw 'Must specify either Folder or Folder ID' }

    if ( $VmNames.Count -lt 1 -and $VPGVirtualMachines.Count -lt 1 ) { throw 'Must specify at least one VmName or VPGVirtualMachine' }

    #Get Identifiers
    $LocalSiteID = Get-ZertoLocalSite | Select-Object -ExpandProperty SiteIdentifier
    if ([string]::IsNullOrEmpty($LocalSiteID)  ) { throw 'Could not find Local Site ID' }

    ## apply a default if no recovery site ID was provided
    if (-Not $RecoverySiteID) {

        $RecoverySiteID = Get-ZertoVirtualizationSite | Where-Object { $_.VirtualizationSiteName -eq $RecoverySiteName } | Select-Object -ExpandProperty SiteIdentifier
        if ([string]::IsNullOrEmpty($RecoverySiteID)  ) { throw "Could not find Recovery Site ID for $RecoverySiteName " }
    }

    #Get FailoverNeworkID if not specified
    if ($FailoverNetwork ) {
        $FailoverNetworkID = Get-ZertoSiteNetwork -ZertoSiteIdentifier $RecoverySiteID | Where-Object { $_.VirtualizationNetworkName -eq $FailoverNetwork } | Select-Object -Expand 'NetworkIdentifier'
        if ([string]::IsNullOrEmpty($FailoverNetworkID)  ) { throw "Could not find Failover Network ID for $FailoverNetwork " }
        if ( $FailoverNetworkID.Count -gt 1 ) { throw "More than one Failover Network ID has the name $FailoverNetwork " }
    }

    if ($TestNetwork ) {
        $TestNetworkID = Get-ZertoSiteNetwork -ZertoSiteIdentifier $RecoverySiteID | Where-Object { $_.VirtualizationNetworkName -eq $TestNetwork } | Select-Object -Expand 'NetworkIdentifier'
        if ([string]::IsNullOrEmpty($TestNetworkID)  ) { throw "Could not find Test Network ID for $TestNetwork " }
        if ( $TestNetworkID.Count -gt 1 ) { throw "More than one Test Network ID has the name $TestNetwork " }
    }

    if ($ClusterName) {
        $ClusterID = Get-ZertoSiteHostCluster -ZertoSiteIdentifier $RecoverySiteID | Where-Object { $_.VirtualizationClusterName -eq $ClusterName } | Select-Object -ExpandProperty 'ClusterIdentifier'
        if ([string]::IsNullOrEmpty($ClusterID)  ) { throw "Could not find Cluster ID for $ClusterName " }
        $HostID = $null
    } elseif ($HostName) {
        $ClusterID = $null
        $HostID = Get-ZertoSiteHost -ZertoSiteIdentifier $RecoverySiteID | Where-Object { $_.VirtualizationHostName -eq $HostName } | Select-Object -ExpandProperty 'HostIdentifier'
        if ([string]::IsNullOrEmpty($HostID)  ) { throw "Could not find Host ID for $HostName " }
    }

    if ($DatastoreName) {
        $DatastoreID = Get-ZertoSiteDatastore -ZertoSiteIdentifier $RecoverySiteID | Where-Object { $_.DatastoreName -eq $DatastoreName } | Select-Object -ExpandProperty DatastoreIdentifier
        if ([string]::IsNullOrEmpty($DatastoreID)  ) { throw "Could not find Datastore ID for $DatastoreName " }
        $DatastoreClusterID = $null
    } elseif ($DatastoreClusterName) {
        $DatastoreID = $null
        $DatastoreClusterID = Get-ZertoSiteDatastoreCluster -ZertoSiteIdentifier $RecoverySiteId | Where-Object { $_.DatastoreClusterName -eq $DatastoreClusterName } | Select-Object -ExpandProperty DatastoreClusterIdentifier
        if ([string]::IsNullOrEmpty($DatastoreClusterID)  ) { throw "Could not find Datastore Cluster ID for $DatastoreclusterName " }
    }

    if (-NOT $JournalUseDefault) {
        if ($JournalDatastoreName) {
            $JournalDatastoreID = Get-ZertoSiteDatastore -ZertoSiteIdentifier $RecoverySiteID | Where-Object { $_.DatastoreName -eq $JournalDatastoreName } | Select-Object -ExpandProperty DatastoreIdentifier
            $JournalDatastoreClusterID = $null
            if ([string]::IsNullOrEmpty($JournalDatastoreID)  ) { throw "Could not find Datastore ID for $JournalDatastoreName " }
        } elseif ($JournalDatastoreClusterName) {
            $JournalDatastoreID = $null
            $JournalDatastoreClusterID = Get-ZertoSiteDatastoreCluster -ZertoSiteIdentifier $RecoverySiteId | Where-Object { $_.DatastoreClusterName -eq $JournalDatastoreClusterName } | Select-Object -ExpandProperty DatastoreClusterIdentifier
            if ([string]::IsNullOrEmpty($JournalDatastoreClusterID)  ) { throw "Could not find Datastore Cluster ID for $JournalDatastoreclusterName " }
        }
    }

    #Get Folder
    if ($Folder ) {
        $FolderID = Get-ZertoSiteFolder -ZertoSiteIdentifier $RecoverySiteID | Where-Object { $_.FolderName -eq $Folder } | Select-Object -ExpandProperty 'FolderIdentifier'
        if ([string]::IsNullOrEmpty($FolderID)  ) { throw "Could not find Folder ID for $Folder " }
        if ( $FolderID.Count -gt 1 ) { throw "More than one Folder ID has the name $Folder " }
    }

    #Get ResourcePool if not specified
    if ($ResourcePoolName ) {
        $ResourcePoolId = Get-ZertoSiteResourcePool -ZertoSiteIdentifier $RecoverySiteID | Where-Object { $_.ResourcePoolName -eq $ResourcePoolName } | Select-Object -ExpandProperty 'ResourcePoolIdentifier'
        if ([string]::IsNullOrEmpty($ResourcePoolId)  ) { throw "Could not find Resource Pool ID for $ResourcePoolName " }
        if ( $ResourcePoolId.Count -gt 1 ) { throw "More than one Resource pool ID has the name $ResourcePoolName " }
    }

    #Save our VMID in a VMName/ID Hash
    $VMNameAndIDHash = [ordered] @{}
    if ($VmNames) {
        $VmNames | ForEach-Object {
            #VM's are always from LocalSite
            $VMID = Get-ZertoSiteVM -ZertoSiteIdentifier $LocalSiteID | Where-Object { $_.VMName -in $VmNames } | Select-Object -ExpandProperty 'VmIdentifier'
            $VMNameAndIDHash.Add($_, $VMID)
        }
    } elseif ($VPGVirtualMachines) {
        $VPGVirtualMachines | ForEach-Object {
            #VM's are always from LocalSite
            $VMID = Get-ZertoSiteVMID -ZertoSiteIdentifier $LocalSiteID -VMName $_.VMName
            $VMNameAndIDHash.Add($_.VMName , $VMID)
        }
    } else {
        throw "No VM's specified"
    }

    if ( $RecoverySiteID.Count -gt 1 ) { throw "More than one Recovery site has the name $RecoverySiteName " }
    if ($ClusterName) {
        if ( $ClusterID.Count -gt 1 ) { throw "More than one Cluster ID has the name $ClusterName " }
    } elseif ($HostName) {
        if ( $HostID.Count -gt 1 ) { throw "More than one Host ID has the name $HostName  " }
    }

    if ($DatastoreName) {
        if ( $DatastoreID.Count -gt 1 ) { throw "More than one Datastore ID has the name $DatastoreName " }
    } elseif ($DatastoreClusterName) {
        if ( $DatastoreClusterID.Count -gt 1 ) { throw "More than one Datastore Cluster ID has the name $DatastoreclusterName " }
    }

    if (-NOT $JournalUseDefault) {
        if ($JournalDatastoreName) {
            if ( $JournalDatastoreID.Count -gt 1 ) { throw "More than one Datastore ID has the name $JournalDatastoreName " }
        } elseif ($JournalDatastoreClusterName) {
            if ( $JournalDatastoreClusterID.Count -gt 1 ) { throw "More than one Datastore Cluster ID has the name $JournalDatastoreclusterName " }
        }
    }

    #Build up our json object
    $NewBodyHash = [ordered] @{}
    $NewBodyHash.Add('Backup' , $null)
    $Basic = [ordered] @{}
    $Basic.Add( 'JournalHistoryInHours', $JournalHistoryInHours)
    $Basic.Add( 'Name', $VPGName)
    $Basic.Add( 'Priority', $Priority.ToString() )
    $Basic.Add( 'VpgType', $VpgType.ToString() )
    $Basic.Add( 'ProtectedSiteIdentifier', $LocalSiteID)
    $Basic.Add( 'RecoverySiteIdentifier', $RecoverySiteID )
    $Basic.Add( 'RpoInSeconds', $RPOAlertInSeconds)
    $Basic.Add( 'ServiceProfileIdentifier', $null )
    $Basic.Add( 'TestIntervalInMinutes', $TestIntervalInMinutes )
    $Basic.Add( 'UseWanCompression', $true )
    $Basic.Add( 'ZorgIdentifier', $null )
    $NewBodyHash.Add('Basic' , $Basic)
    $BootGroupsItem = [ordered] @{}
    $BootGroupsItem.Add( 'BootDelayInSeconds', 0)
    $BootGroupsItem.Add( 'BootGroupIdentifier', '00000000-0000-0000-0000-000000000000')
    $BootGroupsItem.Add( 'Name', 'Default')
    $BootGroupsArray = @()
    $BootGroupsArray += $BootGroupsItem
    $BootGroups = @{'BootGroups' = $BootGroupsArray }
    $NewBodyHash.Add('BootGroups' , $BootGroups )
    $Journal = [ordered] @{}
    if ($JournalUseDefault) {
        # Use the defaults
        if ($DatastoreID) {
           $Journal.Add( 'DatastoreIdentifier', $DatastoreID)
        } else {
           $Journal.Add( 'DatastoreIdentifier', $null)
        }
    } else {
        if ($JournalDatastoreID) {
            $Journal.Add( 'DatastoreIdentifier', $JournalDatastoreID)
        } else {
            $Journal.Add( 'DatastoreClusterIdentifier', $DatastoreID)
        }
    }
    $JournalLimit = [ordered] @{}
    #This should allow the %, but currently not a parameter
    if ($JournalHardLimitMB -gt 0) {
        $JournalLimit.Add( 'HardLimitInMB', $JournalHardLimitMB )
        $JournalLimit.Add( 'HardLimitInPercent', $null )
    } else {
        $JournalLimit.Add( 'HardLimitInMB', $JournalHardLimitMB )
        $JournalLimit.Add( 'HardLimitInPercent', $null )
    }
    $JournalLimit.Add( 'WarningThresholdInMB', $JournalWarningThresholdMB )
    $JournalLimit.Add( 'WarningThresholdInPercent', $null )
    $Journal.Add( 'Limitation', $JournalLimit)
    $NewBodyHash.Add('Journal' , $Journal )
    $Networks = [ordered] @{}
    $Failover = [ordered] @{}
    $DefaultNetworkIdentifier = [ordered] @{}
    $DefaultNetworkIdentifier.Add('DefaultNetworkIdentifier', $FailoverNetworkID)
    $Failover.Add( 'Hypervisor', $DefaultNetworkIdentifier )
    $Networks.Add( 'Failover', $Failover)
    $FailoverTest = [ordered] @{}
    $DefaultNetworkIdentifier = [ordered] @{}
    $DefaultNetworkIdentifier.Add('DefaultNetworkIdentifier', $TestNetworkID)
    $FailoverTest.Add( 'Hypervisor', $DefaultNetworkIdentifier )
    $Networks.Add( 'FailoverTest', $FailoverTest)
    $NewBodyHash.Add('Networks' , $Networks )
    $Recovery = [ordered] @{}
    if ($DatastoreID) {
        $Recovery.Add( 'DefaultDatastoreIdentifier', $DatastoreID)
    } else {
        #### NOTE THIS IS BROKEN
        $Recovery.Add( 'DefaultDatastoreClusterIdentifier', $DatastoreClusterID)
        # $Recovery.Add( 'DefaultDatastoreClusterIdentifier', $null)
        $Recovery.Add( 'DefaultDatastoreIdentifier', $null)
    }
    $Recovery.Add( 'DefaultFolderIdentifier', $FolderID)
    if ($ClusterID) {
        $Recovery.Add( 'DefaultHostClusterIdentifier', $ClusterID)
        $Recovery.Add( 'DefaultHostIdentifier', $null)
    } else {
        $Recovery.Add( 'DefaultHostClusterIdentifier', $null)
        $Recovery.Add( 'DefaultHostIdentifier', $HostID)
    }
    $Recovery.Add( 'ResourcePoolIdentifier', $ResourcePoolId)
    $NewBodyHash.Add( 'Recovery' , $Recovery )
    $Scripting = [ordered] @{}
    $Scripting.Add( 'PostBackup', $null)
    $PostRecovery = [ordered] @{}
    $PostRecovery.Add( 'Command', $null)
    $PostRecovery.Add( 'Parameters', $null)
    $PostRecovery.Add( 'TimeoutInSeconds', 0)
    $Scripting.Add( 'PostRecovery', $PostRecovery)
    $PreRecovery = [ordered] @{}
    $PreRecovery.Add( 'Command', $null)
    $PreRecovery.Add( 'Parameters', $null)
    $PreRecovery.Add( 'TimeoutInSeconds', 0)
    $Scripting.Add( 'PreRecovery', $PreRecovery)
    $NewBodyHash.Add( 'Scripting' , $Scripting )
    $VMArray = @()
    if ($VmNames) {
        #This section is VM + ID only
        if ($VMNameAndIDHash.Keys.Count -gt 0) {
            $VMNameAndIDHash.Keys | ForEach-Object {
                $VMArray += @{ 'VmIdentifier' = $VMNameAndIDHash[$_] }
            }
        }
    } elseif ($VPGVirtualMachines) {
        $VPGVirtualMachines | ForEach-Object {
            #region VM Foreach
            $NewVmHash = [ordered] @{}
            #Lookup ID from $VMNameAndIDHash
            $NewVmHash.Add('VmIdentifier' , $VMNameAndIDHash[$_.VMName] )
            $NewVmHash.Add('BootGroupIdentifier', '00000000-0000-0000-0000-000000000000' )
            #Loop through our NICs
            $AllNics = @()
            $_.VPGFailoverIPAddresses | ForEach-Object {
                $Nic = [ordered] @{}
                $Nic.Add( 'NicIdentifier' , $_.NicName)
                $NicFail = [ordered] @{}
                $NicFailHyper = [ordered] @{}
                $NicFailHyper.Add('DnsSuffix', $_.DnsSuffix)
                $NicFailHyperIP = [ordered] @{}
                if ($_.UseDHCP) {
                    $NicFailHyperIP.Add('Gateway', '')
                    $NicFailHyperIP.Add('IsDhcp', $true)
                    $NicFailHyperIP.Add('PrimaryDns', '')
                    $NicFailHyperIP.Add('SecondaryDns', '')
                    $NicFailHyperIP.Add('StaticIp', '')
                    $NicFailHyperIP.Add('SubnetMask', '')
                } else {
                    $NicFailHyperIP.Add('Gateway', $_.Gateway)
                    $NicFailHyperIP.Add('IsDhcp', $false)
                    $NicFailHyperIP.Add('PrimaryDns', $_.Dns1)
                    $NicFailHyperIP.Add('SecondaryDns', $_.Dns2)
                    $NicFailHyperIP.Add('StaticIp', $_.IPAddress)
                    $NicFailHyperIP.Add('SubnetMask', $_.SubnetMask)
                }
                $NicFailHyper.Add('IpConfig', $NicFailHyperIP)
                if ($_.NetworkID) { $NicFailHyper.Add( 'NetworkIdentifier' , $_.NetworkID) }
                $NicFailHyper.Add('ShouldReplaceMacAddress' , $_.ReplaceMAC)
                $NicFail.Add( 'Hypervisor', $NicFailHyper)
                #Add Failover to NIC
                $Nic.Add('Failover', $NicFail)
                If ($_.TestIPAddress -or $_.TestUseDHCP) {
                    $NicTest = [ordered] @{}
                    $NicTestHyper = [ordered] @{}
                    $NicTestHyper.Add('DnsSuffix', $_.TestDnsSuffix)
                    $NicTestHyperIP = [ordered] @{}
                    if ($_.TestUseDHCP) {
                        $NicTestHyperIP.Add('Gateway', '')
                        $NicTestHyperIP.Add('IsDhcp', $true)
                        $NicTestHyperIP.Add('PrimaryDns', '')
                        $NicTestHyperIP.Add('SecondaryDns', '')
                        $NicTestHyperIP.Add('StaticIp', '')
                        $NicTestHyperIP.Add('SubnetMask', '')
                    } else {
                        $NicTestHyperIP.Add('Gateway', $_.TestGateway)
                        $NicTestHyperIP.Add('IsDhcp', $false)
                        $NicTestHyperIP.Add('PrimaryDns', $_.TestDns1)
                        $NicTestHyperIP.Add('SecondaryDns', $_.TestDns2)
                        $NicTestHyperIP.Add('StaticIp', $_.TestIPAddress)
                        $NicTestHyperIP.Add('SubnetMask', $_.TestSubnetMask)
                    }
                    $NicTestHyper.Add('IpConfig', $NicTestHyperIP)
                    if ($_.TestNetworkID) { $NicTestHyper.Add( 'NetworkIdentifier' , $_.TestNetworkID) }
                    $NicTestHyper.Add( 'ShouldReplaceMacAddress' , $_.TestReplaceMAC)
                    $NicTest.Add('Hypervisor', $NicTestHyper)
                    #Add Failover Test to NIC
                    $Nic.Add('FailoverTest', $NicTest)
                }

                $AllNics += $Nic
            }  #end of foreach $_.VPGFailoverIPAddresses
            $NewVmHash.Add('Nics', $AllNics )
            #Add recovery block if needed
            If ($_.VPGVMRecovery) {
                $VMRecovery = [ordered] @{}
                #Don't send blanks
                if ($_.VPGVMRecovery.DatastoreClusterIdentifier) { $VMRecovery.Add( 'DatastoreClusterIdentifier', $_.VPGVMRecovery.DatastoreClusterIdentifier) }
                if ($_.VPGVMRecovery.DatastoreIdentifier) { $VMRecovery.Add( 'DatastoreIdentifier', $_.VPGVMRecovery.DatastoreIdentifier) }
                if ($_.VPGVMRecovery.FolderIdentifier) { $VMRecovery.Add( 'FolderIdentifier', $_.VPGVMRecovery.FolderIdentifier) }
                if ($_.VPGVMRecovery.HostClusterIdentifier) { $VMRecovery.Add( 'HostClusterIdentifier', $_.VPGVMRecovery.HostClusterIdentifier) }
                if ($_.VPGVMRecovery.HostIdentifier) { $VMRecovery.Add( 'HostIdentifier', $_.VPGVMRecovery.HostIdentifier) }
                if ($_.VPGVMRecovery.ResourcePoolIdentifier) { $VMRecovery.Add( 'ResourcePoolIdentifier', $_.VPGVMRecovery.ResourcePoolIdentifier) }
                $NewVmHash.Add('Recovery', $VMRecovery)
            }
            #Add this VM Hash to the VMArray
            $VMArray += $NewVmHash
            #endregion
        }
    } else {
        throw "No VM's specified"
    }
    $NewBodyHash.Add( 'Vms' , $VMArray)

    #
    #Convert VPG Hash to JSON - Remember DEPTH!!!
    $NewVPGJson = $NewBodyHash | ConvertTo-Json -Depth 20

    $FullURL = $baseURL + 'vpgsettings'
    Write-Verbose $FullURL
    Write-Verbose $NewVPGJson

    if ($DumpJson ) {
        #Display JSON, and exit
        $NewVPGJson
        return
    }

    #This POST creates the settings
    $VPGSettingsID = Invoke-RestMethod -Uri $FullURL -TimeoutSec 100 -ContentType $TypeJSON -Method Post -Body $NewVPGJson -WebSession $ZertoSessionConfig.ZertoWebSession @ZertoCertSettings
    if ( $null -eq $VPGSettingsID ) { throw 'Error creating VPG' }
    Write-Verbose ('VPGSettingsID: ' + $VPGSettingsID)

    $VPGSetting = Get-ZertoVPGSetting -ZertoVpgSettingsIdentifier $VPGSettingsID
    if ( $null -eq $VPGSetting ) { throw 'Error retrieving VPGSettings for VPGSettingsID' }

    Write-Verbose $VPGSetting

    if (-not $VPGCommit) {
        Write-Host "VPG Setting $VPGSettingsID created.  Commit with '" -NoNewline -ForegroundColor Red
        Write-Host "Submit-ZertoVPGSetting -ZertoVpgSettingsIdentifier $VPGSettingsID" -ForegroundColor Cyan -NoNewline
        Write-Host "'" -ForegroundColor Red
        return $VPGSettingsID
    }

    #Returns VPG Task ID
    $Result = Submit-ZertoVPGSetting -ZertoVpgSettingsIdentifier $VPGSettingsID
    return $Result

}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Remove-ZertoVPG {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Identifier')] [string] $ZertoVpgIdentifier,
        [Parameter(Mandatory = $false, HelpMessage = 'Force Remove')] [Bool] $Force = $false,
        [Parameter(Mandatory = $false, HelpMessage = 'Keep Recovery Volumes')] [Bool] $KeepRecoveryVolumes = $false
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
        throw 'Missing Zerto VPG Identifier'
    }

    $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier
    Write-Verbose $FullURL

    $BodyHash = [ordered] @{}
    $BodyHash.Add('Force', $Force)
    $BodyHash.Add('KeepRecoveryVolumes', $KeepRecoveryVolumes)
    $Body = $BodyHash | ConvertTo-Json
    Write-Verbose $Body

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Delete -Body $Body
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Invoke-ZertoVPGForceSync {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Identifier')] [string] $ZertoVpgIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
        throw 'Missing Zerto VPG Identifier'
    }

    $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier + '/forcesync'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Post
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Start-ZertoVPGClone {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Identifier')] [string] $ZertoVpgIdentifier,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto VPG Checkpoint Identifier (default is latest)')] [string] $ZertoVpgCheckpointIdentifier,
        [Parameter(Mandatory = $false, HelpMessage = 'DatastoreIdentifier')] [string] $DatastoreIdentifier
        , [Parameter(Mandatory = $false, HelpMessage = 'Dump Json without posting for debug')] [switch] $DumpJson
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
        throw 'Missing Zerto VPG Identifier'
    }

    $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier + '/Clonestart'
    Write-Verbose $FullURL

    #Both parameters are optional
    $BodyHash = [ordered] @{}
    if (-not ( [string]::IsNullOrEmpty($ZertoVpgCheckpointIdentifier) )  ) {
        $BodyHash.Add('CheckpointIdentifier', $ZertoVpgCheckpointIdentifier)
    }
    if (-not ( [string]::IsNullOrEmpty($DatastoreIdentifier) )  ) {
        $BodyHash.Add('DatastoreIdentifier', $DatastoreIdentifier)
    }

    $BodyJson = $BodyHash | ConvertTo-Json
    Write-Verbose $BodyJson
    if ($DumpJson ) {
        #Display JSON, and exit
        Write-Host $BodyJson
        return
    }
    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Post -Body $BodyJson
    } catch {
        throw $_.Exception.Message
    }

    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Stop-ZertoVPGClone {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Identifier')] [string] $ZertoVpgIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
        throw 'Missing Zerto VPG Identifier'
    }

    $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier + '/CloneAbort'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Post
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Start-ZertoVPGFailover {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Identifier')] [string] $ZertoVpgIdentifier,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto VPG Checkpoint Identifier (default is latest)')] [string] $ZertoVpgCheckpointIdentifier,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Commit Policy')] [ZertoCommitPolicy] $CommitPolicy = 'Commit',
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Commit Value in seconds')] [string] $CommitInSeconds,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Shutdown Policy')] [ZertoShutdownPolicy] $ShutdownPolicy = 'Shutdown',
        [Parameter(Mandatory = $true, HelpMessage = 'Time to wait before shutdown in seconds')] [string] $TimeToWaitBeforeShutdownInSec,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Reverse Protection')] [bool] $ReverseProtection = $true
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
        throw 'Missing Zerto VPG Identifier'
    }

    $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier + '/Failover'
    Write-Verbose $FullURL

    $BodyHash = [ordered] @{}
    if ($ZertoVpgCheckpointIdentifier) {
        $BodyHash.Add('CheckpointIdentifier', $ZertoVpgCheckpointIdentifier )
    } else {
        $BodyHash.Add('CheckpointIdentifier', (Get-ZertoVPGCheckpointLastID -ZertoVpgIdentifier $ZertoVpgIdentifier )  )
    }
    $BodyHash.Add('CommitPolicy', $CommitPolicy )
    #$Failover.Add("CommitValue", $CommitInSeconds)
    $BodyHash.Add('ShutdownPolicy', $ShutdownPolicy )
    $BodyHash.Add('TimeToWaitBeforeShutdownInSec', $TimeToWaitBeforeShutdownInSec )
    $BodyHash.Add('IsReverseProtection', $ReverseProtection )
    $BodyJson = $BodyHash | ConvertTo-Json
    Write-Verbose $BodyJson

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'POST'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Post -Body $BodyJson
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Start-ZertoVPGMove {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Identifier')] [string] $ZertoVpgIdentifier,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Commit Policy')] [ZertoCommitPolicy] $CommitPolicy = 'Commit',
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Commit Policy Timeout in seconds')] [int32] $CommitPolicyTimeout = 3600,
        [Parameter(Mandatory = $false, HelpMessage = 'Force Source Machine to shutdown')] [bool] $ForceShutdown = $False,
        [Parameter(Mandatory = $false, HelpMessage = 'Keep Source VMs')] [bool] $KeepSourceVMs = $False,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Reverse Protection')] [bool] $ReverseProtection = $false,
        [Parameter(Mandatory = $false, HelpMessage = 'Continue on PreScript Failure')] [bool] $ContinueOnPreScriptFailure = $True
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
        throw 'Missing Zerto VPG Identifier'
    }

    $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier + '/Move'
    Write-Verbose $FullURL

    $BodyHash = [ordered] @{}
    $BodyHash.Add('commitPolicy', $CommitPolicy )
    if(-Not $CommitPolicy -eq 'None'){
        $BodyHash.Add('commitPolicyTimeout', $CommitPolicyTimeout )
    }
    $BodyHash.Add('forceShutdown', $ForceShutdown )
    $BodyHash.Add('reverseProtection', $ReverseProtection )
    $BodyHash.Add('keepSourceVms', $KeepSourceVMs )
    $BodyHash.Add('continueOnPreScriptFailure', $ContinueOnPreScriptFailure )
    $BodyJson = $BodyHash | ConvertTo-Json
    Write-Verbose $BodyJson

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'POST'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Post -Body $BodyJson
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Invoke-ZertoVPGFailoverCommit {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Identifier')] [string] $ZertoVpgIdentifier,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Reverse Protection')] [bool] $ReverseProtection = $true
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
        throw 'Missing Zerto VPG Identifier'
    }

    $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier + '/failovercommit'
    Write-Verbose $FullURL

    $BodyHash = [ordered] @{}
    $BodyHash.Add('IsReverseProtection', $ReverseProtection)
    $BodyJson = $BodyHash | ConvertTo-Json -Depth 20

    Write-Verbose $BodyJson
    if ($DumpJson ) {
        #Display JSON, and exit
        Write-Host $BodyJson
        return
    }

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method POST -Body $BodyJson
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Invoke-ZertoVPGMoveCommit {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Identifier')] [string] $ZertoVpgIdentifier,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Reverse Protection')] [bool] $ReverseProtection = $true,
        [Parameter(Mandatory = $false, HelpMessage = 'Keep Source VMs')] [bool] $KeepSourceVMs= $true
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
        throw 'Missing Zerto VPG Identifier'
    }

    $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier + '/MoveCommit'
    Write-Verbose $FullURL

    $BodyHash = [ordered] @{}
    $BodyHash.Add('IsReverseProtection', $ReverseProtection)
    $BodyHash.Add('keepSourceVms', $KeepSourceVMs)
    $BodyJson = $BodyHash | ConvertTo-Json -Depth 20

    Write-Verbose $BodyJson

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method POST -Body $BodyJson
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}


# .ExternalHelp ZertoModule.psm1-help.xml
Function Invoke-ZertoVPGFailoverRollback {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG  Identifier')] [string] $ZertoVpgIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
        throw 'Missing Zerto VPG  Identifier'
    }

    $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier + '/failoverRollback'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method POST
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Start-ZertoVPGFailoverTest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Identifier')] [string] $ZertoVpgIdentifier,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto VPG Checkpoint Identifier')] [string] $ZertoVpgCheckpointIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
        throw 'Missing Zerto VPG Identifier'
    }

    $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier + '/FailoverTest'
    Write-Verbose $FullURL

    if ($ZertoVpgCheckpointIdentifier) {
        $BodyHash = [ordered] @{}
        $BodyHash.Add('checkpointIdentifier', $ZertoVpgCheckpointIdentifier)
        $Body = $BodyHash | ConvertTo-Json
        Write-Verbose $Body
    }

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Post -Body $Body
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Stop-ZertoVPGFailoverTest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Identifier')] [string] $ZertoVpgIdentifier,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Failover Test success status')] [bool] $FailoverTestSuccess = $true,
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Failover Test result summary')] [string] $FailoverTestSummary
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
        throw 'Missing Zerto VPG Identifier'
    }

    $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier + '/FailoverTestStop'
    Write-Verbose $FullURL

    $BodyHash = [ordered] @{}
    $BodyHash.Add('FailoverTestSuccess', $FailoverTestSuccess)
    $BodyHash.Add('FailoverTestSummary', $FailoverTestSummary)
    $Body = $BodyHash | ConvertTo-Json
    Write-Verbose $Body

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Post -Body $Body
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Invoke-ZertoVPGPause {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG  Identifier')] [string] $ZertoVpgIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
        throw 'Missing Zerto VPG  Identifier'
    }

    $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier + '/pause'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method POST
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Invoke-ZertoVPGResume {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG  Identifier')] [string] $ZertoVpgIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgIdentifier)  ) {
        throw 'Missing Zerto VPG  Identifier'
    }

    $FullURL = $baseURL + 'vpgs/' + $ZertoVpgIdentifier + '/resume'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method POST
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}
#endregion

#region Zerto VPG Settings

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGSetting {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $false, ParameterSetName = 'ID', HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'

    switch ($PsCmdlet.ParameterSetName) {
        'ID' {
            if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
                throw 'Missing Zerto VPG Settings Identifier'
            }

            $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier
        }
        Default {
            $FullURL = $baseURL + 'vpgSettings'
        }
    }
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGSettingID {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Setting Name')] [string] $VpgSettingName
    )

    $ID = Get-ZertoVPGSetting -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken | `
            Where-Object { $_.Basic.Name -eq $VpgSettingName } | `
            Select-Object VpgSettingsIdentifier -ExpandProperty VpgSettingsIdentifier

    if ($ID.Count -gt 1) { Throw "'$VpgSettingName' returned more than one ID" }
    if ($ID.Count -eq 0) { Throw "'$VpgSettingName' was not found" }

    return $ID.ToString()
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Set-ZertoVPGSetting {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings obejct')] [ZertoVPGSetting] $ZertoVPGSetting
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'



    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier
    Write-Verbose $FullURL
    $Body = $ZertoVPGSetting | ConvertTo-Json -Depth 99
    Write-Verbose $Body

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method PUT -Body $Body
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Add-ZertoVPGSetting {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings obejct')] [ZertoVPGSetting] $ZertoVPGSetting
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'



    $FullURL = $baseURL + 'vpgSettings'
    Write-Verbose $FullURL
    $Body = $ZertoVPGSetting | ConvertTo-Json -Depth 99
    Write-Verbose $Body

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method POST -Body $Body
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Submit-ZertoVPGSetting {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'

    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/commit'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method POST
    } catch {
        throw $_.ErrorDetails.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Remove-ZertoVPGSetting {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Delete
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGSettingBackup {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/backup'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Set-ZertoVPGSettingBackup {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Basic obejct')] [ZertoVPGSettingBackup] $ZertoVPGSettingBackup
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/backup'
    Write-Verbose $FullURL
    $Body = $ZertoVPGSettingBackup | ConvertTo-Json -Depth 10
    Write-Verbose $Body

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Put -Body $Body
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Remove-ZertoVPGSettingBackup {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/backup'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Delete
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGSettingBackupDayOfWeek {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/backup/dayofweek'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGSettingBackupRetentionPeriod {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/backup/retentionperiod'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGSettingBackupSchedulerPeriod {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/backup/schedulerperiod'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGSettingBasic {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/basic'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Set-ZertoVPGSettingBasic {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Basic object')] [ZertoVPGSettingBasic] $ZertoVpgSettingBasic
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/basic'
    Write-Verbose $FullURL
    $Body = $ZertoVpgSettingBasic | ConvertTo-Json -Depth 10
    Write-Verbose $Body

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Put -Body $Body
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Remove-ZertoVPGSettingBasic {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/basic'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Delete
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGSettingBootGroup {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/bootgroup'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Set-ZertoVPGSettingBootGroup {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings BootGroup object')] [ZertoVpgSettingBootGroups] $ZertoVpgSettingBootGroup
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/bootgroup'
    Write-Verbose $FullURL
    $Body = $ZertoVpgSettingBootGroup | ConvertTo-Json -Depth 10
    Write-Verbose $Body

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Put -Body $Body
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Remove-ZertoVPGSettingBootGroup {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/bootgroup'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Delete
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGSettingJournal {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/journal'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Set-ZertoVPGSettingJournal {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Journal object')] [ZertoVPGSettingJournal] $ZertoVPGSettingJournal
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/journal'
    Write-Verbose $FullURL
    $Body = $ZertoVPGSettingJournal | ConvertTo-Json -Depth 10
    Write-Verbose $Body

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Put -Body $Body
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGSettingNetwork {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/networks'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Set-ZertoVPGSettingNetwork {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Network object')] [ZertoVPGSettingNetworks] $ZertoVPGSettingNetworks
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/networks'
    Write-Verbose $FullURL
    $Body = $ZertoVPGSettingNetworks | ConvertTo-Json -Depth 10
    Write-Verbose $Body

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Put -Body $Body
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Remove-ZertoVPGSettingNetwork {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/networks'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Delete
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGSettingPriority {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/priority'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGSettingRecovery {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/recovery'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Set-ZertoVPGSettingRecovery {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Scripting object')] [ZertoVPGSettingRecovery] $ZertoVPGSettingRecovery
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/recovery'
    Write-Verbose $FullURL
    $Body = $ZertoVPGSettingRecovery | ConvertTo-Json -Depth 10
    Write-Verbose $Body

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Put -Body $Body
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Remove-ZertoVPGSettingRecovery {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/recovery'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Delete
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGSettingScripting {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/scripting'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Set-ZertoVPGSettingScripting {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Scripting object')] [ZertoVPGSettingScripting] $ZertoVPGSettingScripting
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/scripting'
    Write-Verbose $FullURL
    $Body = $ZertoVPGSettingScripting | ConvertTo-Json -Depth 10
    Write-Verbose $Body

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Put -Body $Body
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Remove-ZertoVPGSettingScripting {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/scripting'
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Delete
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGSettingVM {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = 'ID', HelpMessage = 'Zerto VM Identifier')] [string] $ZertoVmIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    switch ($PsCmdlet.ParameterSetName) {
        'ID' {
            if ([string]::IsNullOrEmpty($ZertoVmIdentifier)  ) {
                throw 'Missing Zerto VPG Settings VM Identifier'
            }

            $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/vms/' + $ZertoVmIdentifier
        }
        Default {
            $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/vms'
        }
    }
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Set-ZertoVPGSettingVM {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings VM ID')] [string] $ZertoVPGSettingVMID,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings VM object')] [ZertoVPGSettingVM] $ZertoVPGSettingVM
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/VMs/' + $ZertoVPGSettingVMID
    Write-Verbose $FullURL
    $Body = $ZertoVPGSettingVM | ConvertTo-Json -Depth 10
    Write-Verbose $Body

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Put -Body $Body
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Remove-ZertoVPGSettingVM {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VM Identifier')] [string] $ZertoVmIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }
    if ([string]::IsNullOrEmpty($ZertoVmIdentifier)  ) {
        throw 'Missing Zerto VM Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/vms/' + $ZertoVmIdentifier
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Delete
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Add-ZertoVPGSettingVM {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings VM object')] [ZertoVPGSettingVM] $ZertoVPGSettingVM
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }

    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/VMs'
    Write-Verbose $FullURL
    $Body = $ZertoVPGSettingVM | ConvertTo-Json -Depth 10
    Write-Verbose $Body

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Post -Body $Body
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGSettingVMNIC {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VM Identifier')] [string] $ZertoVmIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = 'ID', HelpMessage = 'Zerto VM Identifier')] [string] $ZertoNicIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }
    if ([string]::IsNullOrEmpty($ZertoVmIdentifier)  ) {
        throw 'Missing Zerto VM Identifier'
    }

    switch ($PsCmdlet.ParameterSetName) {
        'ID' {
            if ([string]::IsNullOrEmpty($ZertoNicIdentifier)  ) {
                throw 'Missing Zerto NIC Identifier'
            }
            $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/vms/' + $ZertoVmIdentifier + '/nics/' + $ZertoNicIdentifier
        }
        Default {
            $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/vms/' + $ZertoVmIdentifier + '/nics'
        }
    }
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Set-ZertoVPGSettingVMNIC {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VM Identifier')] [string] $ZertoVmIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VM NIC Identifier')] [string] $ZertoNicIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings VM Nic object')] [ZertoVPGSettingVMNic] $ZertoVPGSettingVMNic
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }
    if ([string]::IsNullOrEmpty($ZertoVmIdentifier)  ) {
        throw 'Missing Zerto VM Identifier'
    }
    if ([string]::IsNullOrEmpty($ZertoNicIdentifier)  ) {
        throw 'Missing Zerto NIC Identifier'
    }
    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/vms/' + $ZertoVmIdentifier + '/nics/' + $ZertoNicIdentifier
    Write-Verbose $FullURL
    $Body = $ZertoVPGSettingVMNic | ConvertTo-Json -Depth 10
    Write-Verbose $Body

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method PUT -Body $Body
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Remove-ZertoVPGSettingVMNIC {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VM Identifier')] [string] $ZertoVmIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VM NIC Identifier')] [string] $ZertoNicIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }
    if ([string]::IsNullOrEmpty($ZertoVmIdentifier)  ) {
        throw 'Missing Zerto VM Identifier'
    }
    if ([string]::IsNullOrEmpty($ZertoNicIdentifier)  ) {
        throw 'Missing Zerto NIC Identifier'
    }
    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/vms/' + $ZertoVmIdentifier + '/nics/' + $ZertoNicIdentifier
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method Delete
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVPGSettingVMVolume {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VM Identifier')] [string] $ZertoVmIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = 'ID', HelpMessage = 'Zerto VM Volumne Identifier')] [string] $ZertoVMVolumeIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }
    if ([string]::IsNullOrEmpty($ZertoVmIdentifier)  ) {
        throw 'Missing Zerto VM Identifier'
    }

    switch ($PsCmdlet.ParameterSetName) {
        'ID' {
            if ([string]::IsNullOrEmpty($ZertoVMVolumeIdentifier)  ) {
                throw 'Missing Zerto Volume Identifier'
            }
            $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/vms/' + $ZertoVmIdentifier + '/volumes/' + $ZertoVMVolumeIdentifier
        }
        Default {
            $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/vms/' + $ZertoVmIdentifier + '/volumes'
        }
    }
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Set-ZertoVPGSettingVMVolume {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = 'Default',
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings Identifier')] [string] $ZertoVpgSettingsIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VM Identifier')] [string] $ZertoVmIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VM Volume Identifier')] [string] $ZertoVMVolumeIdentifier,
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VPG Settings VM Volume object')] [ZertoVPGSettingVMVolume] $ZertoVPGSettingVMVolume
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw 'Zerto Session Not Found.  Use New-TMSession command before using features.'
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    } else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = 'https://' + $ZertoSessionConfig.ZertoServer + ':' + $ZertoSessionConfig.ZertoPort + '/v1/'
    $TypeJSON = 'application/json'


    if ([string]::IsNullOrEmpty($ZertoVpgSettingsIdentifier)  ) {
        throw 'Missing Zerto VPG Settings Identifier'
    }
    if ([string]::IsNullOrEmpty($ZertoVmIdentifier)  ) {
        throw 'Missing Zerto VM Identifier'
    }
    if ([string]::IsNullOrEmpty($ZertoVMVolumeIdentifier)  ) {
        throw 'Missing Zerto VM Volume Identifier'
    }
    $FullURL = $baseURL + 'vpgSettings/' + $ZertoVpgSettingsIdentifier + '/vms/' + $ZertoVmIdentifier + '/volumes/' + $ZertoVMVolumeIdentifier
    Write-Verbose $FullURL
    $Body = $ZertoVPGSettingVMVolume | ConvertTo-Json -Depth 10
    Write-Verbose $Body

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings -Method PUT -Body $Body
    } catch {
        throw $_.Exception.Message
    }
    return $Result
}

#endregion