
#region Zerto Virtual Machines

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVM {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto VPG name')] [string] $VPGName,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto VM name')] [string] $VMName,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto VM Status')] [ZertoVPGStatus] $Status,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto VM Substatus')] [ZertoVPGSubstatus] $SubStatus,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Protected Site Type')] [ZertoProtectedSiteType] $ProtectedSiteType,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Recovery Site Type')] [ZertoRecoverySiteType] $RecoverySiteType,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Protected Site Identifier')] [string] $ProtectedSiteIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto Recovery Site Identifier')] [string] $RecoverySiteIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto VM Organization Name')] [string] $OrganizationName,
        [Parameter(Mandatory = $false, ParameterSetName = "Filter", HelpMessage = 'Zerto VM Priority')] [ZertoVPGPriority] $Priority,
        [Parameter(Mandatory = $true, ParameterSetName = "ID", HelpMessage = 'Zerto VM Identifier')] [string] $ZertoVMIdentifier
   )

	## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"



    switch ($PsCmdlet.ParameterSetName) {
        "ID" {
            if ([string]::IsNullOrEmpty($ZertoVMIdentifier)  ) {
                throw "Missing Zerto VM Identifier"
            }

            $FullURL = $baseURL + "vms/" + $ZertoVMIdentifier
        }
        Default {
            $FullURL = $baseURL + "vms"
            if ($VPGName -or $VMName -or $Status -ne $null -or $Substatus -ne $null -or `
                    $ProtectedSiteType -ne $null -or $RecoverySiteType -ne $null -or $ProtectedSiteIdentifier -or $RecoverySiteIdentifier -or $OrganizationName `
                    -or $Priority -ne $null) {
                $qs = [ordered] @{}
                if ($VPGName) { $qs.Add("vpgName", $VPGName) }
                if ($VMName) { $qs.Add("vmName", $VMName) }
                if ($Status -ne $null) { $qs.Add("status", $Status) }
                if ($Substatus -ne $null) { $qs.Add("substatus", $Substatus) }
                if ($ProtectedSiteType -ne $null) { $qs.Add("protectedSiteType", $ProtectedSiteType) }
                if ($RecoverySiteType -ne $null) { $qs.Add("recoverySiteType", $RecoverySiteType) }
                if ($ProtectedSiteIdentifier) { $qs.Add("ProtectedSiteIdentifier", $ProtectedSiteIdentifier) }
                if ($RecoverySiteIdentifier) { $qs.Add("RecoverySiteIdentifier", $RecoverySiteIdentifier) }
                if ($OrganizationName) { $qs.Add("organizationName", $OrganizationName) }
                if ($Priority -ne $null) { $qs.Add("priority", $Priority) }

                $FullURL += Get-QueryStringFromHashTable -QueryStringHash $QS
            }
        }
    }
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVMID {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto VM Name')] [string] $VmName
    )

    $ID = Get-ZertoVM -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken | `
        Where-Object { $_.VmName -eq $VmName } | `
        Select-Object VmIdentifier -ExpandProperty VmIdentifier

    if ($ID.Count -gt 1) { Throw "'$VMName' returned more than one ID" }
    if ($ID.Count -eq 0) { Throw "'$VMName' was not found" }

    return $ID.ToString()
}
#endregion