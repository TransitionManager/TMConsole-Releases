#region Zerto Virtualization Sites

# .ExternalHelp ZertoModule.psm1-help.xml
# Function Get-ZertoSite {
#     [CmdletBinding()]
#     param(
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
#         [Parameter(Mandatory = $false, ParameterSetName = "ID", HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier
#     )
#     switch ($PsCmdlet.ParameterSetName) {
#         "ID" {
#             Return Get-ZertoVirtualizationSite -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken -ZertoSiteIdentifier $ZertoSiteIdentifier
#         }
#         Default {
#             Return Get-ZertoVirtualizationSite -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken
#         }
#     }

#     if ($ZertoSiteIdentifier) {
#     }
#     else {
#         Return Get-ZertoVirtualizationSite -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken
#     }
# }

# # .ExternalHelp ZertoModule.psm1-help.xml
# Function Get-ZertoSiteID {
#     [CmdletBinding()]
#     param(
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Server or ENV:\ZertoServer')] [string] $ZertoServer = ( Get-EnvZertoServer )  ,
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Server URL Port')] [string] $ZertoPort = ( Get-EnvZertoPort ),
#         [Parameter(Mandatory = $false, ValueFromPipeline = $true, HelpMessage = 'Zerto authentication token from Get-ZertoAuthToken or ENV:\ZertoToken')] [Hashtable] $ZertoToken = ( Get-EnvZertoToken ),
#         [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Name')] [string] $ZertoSiteName
#     )

#     Return Get-ZertoVirtualizationSiteID -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken -ZertoSiteName $ZertoSiteName
# }

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoVirtualizationSite {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $false, ParameterSetName = "ID", HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"


    switch ($PsCmdlet.ParameterSetName) {
        "ID" {
            if ([string]::IsNullOrEmpty($ZertoSiteIdentifier)  ) {
                throw "Missing Zerto Site Identifier"
            }
            $FullURL = $baseURL + "virtualizationsites/" + $ZertoSiteIdentifier
        }
        Default {
            $FullURL = $baseURL + "virtualizationsites"
        }
    }
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# # .ExternalHelp ZertoModule.psm1-help.xml
# Function Get-ZertoVirtualizationSiteID {
#     [CmdletBinding()]
#     param(
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Server or ENV:\ZertoServer')] [string] $ZertoServer = ( Get-EnvZertoServer )  ,
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Server URL Port')] [string] $ZertoPort = ( Get-EnvZertoPort ),
#         [Parameter(Mandatory = $false, ValueFromPipeline = $true, HelpMessage = 'Zerto authentication token from Get-ZertoAuthToken or ENV:\ZertoToken')] [Hashtable] $ZertoToken = ( Get-EnvZertoToken ),
#         [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Name')] [string] $ZertoSiteName
#     )

#     $ID = Get-ZertoVirtualizationSite -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken | `
#         Where-Object { $_.VirtualizationSiteName -eq $ZertoSiteName } | `
#         Select-Object SiteIdentifier -ExpandProperty SiteIdentifier

#     if ($ID.Count -gt 1) { Throw "'$ZertoSiteName' returned more than one ID" }
#     if ($ID.Count -eq 0) { Throw "'$ZertoSiteName' was not found" }

#     return $ID.ToString()
# }

#endregion



#region Zerto Site Secondarys

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoSiteDatastoreCluster {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = "ID", HelpMessage = 'Zerto Site Datastore Cluster Identifier')] [string] $ZertoSiteDatastoreClusterIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"


    if ([string]::IsNullOrEmpty($ZertoSiteIdentifier)  ) {
        throw "Missing Zerto Site Identifier"
    }

    $FullURL = $baseURL + "virtualizationsites/" + $ZertoSiteIdentifier + "/datastoreclusters"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }

    #Filter by ID if needed
    switch ($PsCmdlet.ParameterSetName) {
        "ID" {
            $Result = $Result | Where-Object { $_.DatastoreClusterIdentifier -eq $ZertoSiteDatastoreClusterIdentifier }
        }
        Default {
        }
    }
    return $Result
}

# # .ExternalHelp ZertoModule.psm1-help.xml
# Function Get-ZertoSiteDatastoreClusterID {
#     [CmdletBinding()]
#     param(
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Server or ENV:\ZertoServer')] [string] $ZertoServer = ( Get-EnvZertoServer )  ,
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Server URL Port')] [string] $ZertoPort = ( Get-EnvZertoPort ),
#         [Parameter(Mandatory = $false, ValueFromPipeline = $true, HelpMessage = 'Zerto authentication token from Get-ZertoAuthToken or ENV:\ZertoToken')] [Hashtable] $ZertoToken = ( Get-EnvZertoToken ),
#         [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier,
#         [Parameter(Mandatory = $true, HelpMessage = 'vCenter Datastore Cluster Name')] [string] $DatastoreClusterName
#     )

#     $ID = Get-ZertoSiteDatastoreCluster -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken -ZertoSiteIdentifier $ZertoSiteIdentifier | `
#         Where-Object { $_.DatastoreClusterName -eq $DatastoreClusterName } | `
#         Select-Object DatastoreClusterIdentifier -ExpandProperty DatastoreClusterIdentifier

#     if ($ID.Count -gt 1) { Throw "'$DatastoreClusterName' returned more than one ID" }
#     if ($ID.Count -eq 0) { Throw "'$DatastoreClusterName' was not found" }

#     return $ID.ToString()
# }

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoSiteDatastore {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = "ID", HelpMessage = 'Zerto Site Datastore Identifier')] [string] $ZertoSiteDatastoreIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"

    if ([string]::IsNullOrEmpty($ZertoSiteIdentifier)  ) {
        throw "Missing Zerto Site Identifier"
    }

    $FullURL = $baseURL + "virtualizationsites/" + $ZertoSiteIdentifier + "/datastores"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }

    #Filter by ID if needed
    switch ($PsCmdlet.ParameterSetName) {
        "ID" {
            $Result = $Result | Where-Object { $_.DatastoreIdentifier -eq $ZertoSiteDatastoreIdentifier }
        }
        Default {
        }
    }

    return $Result
}

# # .ExternalHelp ZertoModule.psm1-help.xml
# Function Get-ZertoSiteDatastoreID {
#     [CmdletBinding()]
#     param(
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Server or ENV:\ZertoServer')] [string] $ZertoServer = ( Get-EnvZertoServer )  ,
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Server URL Port')] [string] $ZertoPort = ( Get-EnvZertoPort ),
#         [Parameter(Mandatory = $false, ValueFromPipeline = $true, HelpMessage = 'Zerto authentication token from Get-ZertoAuthToken or ENV:\ZertoToken')] [Hashtable] $ZertoToken = ( Get-EnvZertoToken ),
#         [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier,
#         [Parameter(Mandatory = $true, HelpMessage = 'vCenter Datastore Name')] [string] $DatastoreName
#     )

#     $ID = Get-ZertoSiteDatastore -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken -ZertoSiteIdentifier $ZertoSiteIdentifier | `
#         Where-Object { $_.DatastoreName -eq $DatastoreName } | `
#         Select-Object DatastoreIdentifier -ExpandProperty DatastoreIdentifier

#     if ($ID.Count -gt 1) { Throw "'$DatastoreName' returned more than one ID" }
#     if ($ID.Count -eq 0) { Throw "'$DatastoreName' was not found" }

#     return $ID.ToString()
# }

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoSiteFolder {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = "ID", HelpMessage = 'Zerto Site Folder Identifier')] [string] $ZertoSiteFolderIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"

    if ([string]::IsNullOrEmpty($ZertoSiteIdentifier)  ) {
        throw "Missing Zerto Site Identifier"
    }

    $FullURL = $baseURL + "virtualizationsites/" + $ZertoSiteIdentifier + "/folders"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }

    #Filter by ID if needed
    switch ($PsCmdlet.ParameterSetName) {
        "ID" {
            $Result = $Result | Where-Object { $_.FolderIdentifier -eq $ZertoSiteFolderIdentifier }
        }
        Default {
        }
    }

    return $Result
}

# # .ExternalHelp ZertoModule.psm1-help.xml
# Function Get-ZertoSiteFolderID {
#     [CmdletBinding()]
#     param(
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Server or ENV:\ZertoServer')] [string] $ZertoServer = ( Get-EnvZertoServer )  ,
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Server URL Port')] [string] $ZertoPort = ( Get-EnvZertoPort ),
#         [Parameter(Mandatory = $false, ValueFromPipeline = $true, HelpMessage = 'Zerto authentication token from Get-ZertoAuthToken or ENV:\ZertoToken')] [Hashtable] $ZertoToken = ( Get-EnvZertoToken ),
#         [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier,
#         [Parameter(Mandatory = $true, HelpMessage = 'Zerto vCenter Folder Name')] [string] $FolderName
#     )

#     $ID = Get-ZertoSiteFolder -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken -ZertoSiteIdentifier $ZertoSiteIdentifier | `
#         Where-Object { $_.FolderName -eq $FolderName } | `
#         Select-Object FolderIdentifier -ExpandProperty FolderIdentifier

#     if ($ID.Count -gt 1) { Throw "'$FolderName' returned more than one ID" }
#     if ($ID.Count -eq 0) { Throw "'$FolderName' was not found" }

#     return $ID.ToString()
# }

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoSiteHostCluster {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = "ID", HelpMessage = 'Zerto Site HostCluster Identifier')] [string] $ZertoSiteHostClusterIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"

    if ([string]::IsNullOrEmpty($ZertoSiteIdentifier)  ) {
        throw "Missing Zerto Site Identifier"
    }

    $FullURL = $baseURL + "virtualizationsites/" + $ZertoSiteIdentifier + "/hostclusters"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }

    #Filter by ID if needed
    switch ($PsCmdlet.ParameterSetName) {
        "ID" {
            $Result = $Result | Where-Object { $_.ClusterIdentifier -eq $ZertoSiteHostClusterIdentifier }
        }
        Default {
        }
    }

    return $Result
}

# # .ExternalHelp ZertoModule.psm1-help.xml
# Function Get-ZertoSiteHostClusterID {
#     [CmdletBinding()]
#     param(
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Server or ENV:\ZertoServer')] [string] $ZertoServer = ( Get-EnvZertoServer )  ,
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Server URL Port')] [string] $ZertoPort = ( Get-EnvZertoPort ),
#         [Parameter(Mandatory = $false, ValueFromPipeline = $true, HelpMessage = 'Zerto authentication token from Get-ZertoAuthToken or ENV:\ZertoToken')] [Hashtable] $ZertoToken = ( Get-EnvZertoToken ),
#         [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier,
#         [Parameter(Mandatory = $true, HelpMessage = 'vCenter Host Cluster Name')] [string] $HostClusterName
#     )

#     $ID = Get-ZertoSiteHostCluster -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken -ZertoSiteIdentifier $ZertoSiteIdentifier | `
#         Where-Object { $_.VirtualizationClusterName -eq $HostClusterName } | `
#         Select-Object ClusterIdentifier -ExpandProperty ClusterIdentifier

#     if ($ID.Count -gt 1) { Throw "'$HostClusterName' returned more than one ID" }
#     if ($ID.Count -eq 0) { Throw "'$HostClusterName' was not found" }

#     return $ID.ToString()
# }

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoSiteHost {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = "ID", HelpMessage = 'Zerto Host Identifier')] [string] $ZertoHostIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"

    if ([string]::IsNullOrEmpty($ZertoSiteIdentifier)  ) {
        throw "Missing Zerto Site Identifier"
    }

    switch ($PsCmdlet.ParameterSetName) {
        "ID" {
            if ([string]::IsNullOrEmpty($ZertoHostIdentifier)  ) {
                throw "Missing Zerto Host Identifier"
            }

            $FullURL = $baseURL + "virtualizationsites/" + $ZertoSiteIdentifier + "/hosts/" + $ZertoHostIdentifier
        }
        Default {
            $FullURL = $baseURL + "virtualizationsites/" + $ZertoSiteIdentifier + "/hosts"
        }
    }
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# # .ExternalHelp ZertoModule.psm1-help.xml
# Function Get-ZertoSiteHostID {
#     [CmdletBinding()]
#     param(
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Server or ENV:\ZertoServer')] [string] $ZertoServer = ( Get-EnvZertoServer )  ,
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Server URL Port')] [string] $ZertoPort = ( Get-EnvZertoPort ),
#         [Parameter(Mandatory = $false, ValueFromPipeline = $true, HelpMessage = 'Zerto authentication token from Get-ZertoAuthToken or ENV:\ZertoToken')] [Hashtable] $ZertoToken = ( Get-EnvZertoToken ),
#         [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier,
#         [Parameter(Mandatory = $true, HelpMessage = 'vCenter Host Name')] [string] $HostName
#     )

#     $ID = Get-ZertoSiteHost -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken -ZertoSiteIdentifier $ZertoSiteIdentifier | `
#         Where-Object { $_.VirtualizationHostName -eq $HostName } | `
#         Select-Object HostIdentifier -ExpandProperty HostIdentifier

#     if ($ID.Count -gt 1) { Throw "'$HostName' returned more than one ID" }
#     if ($ID.Count -eq 0) { Throw "'$HostName' was not found" }

#     return $ID.ToString()
# }

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoSiteNetwork {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = "ID", HelpMessage = 'Zerto Site Network Identifier')] [string] $ZertoSiteNetworkIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"

    if ([string]::IsNullOrEmpty($ZertoSiteIdentifier)  ) {
        throw "Missing Zerto Site Identifier"
    }

    $FullURL = $baseURL + "virtualizationsites/" + $ZertoSiteIdentifier + "/networks"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }

    #Filter by ID if needed
    switch ($PsCmdlet.ParameterSetName) {
        "ID" {
            $Result = $Result | Where-Object { $_.NetworkIdentifier -eq $ZertoSiteNetworkIdentifier }
        }
        Default {
        }
    }

    return $Result
}

# # .ExternalHelp ZertoModule.psm1-help.xml
# Function Get-ZertoSiteNetworkID {
#     [CmdletBinding()]
#     param(
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Server or ENV:\ZertoServer')] [string] $ZertoServer = ( Get-EnvZertoServer )  ,
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Server URL Port')] [string] $ZertoPort = ( Get-EnvZertoPort ),
#         [Parameter(Mandatory = $false, ValueFromPipeline = $true, HelpMessage = 'Zerto authentication token from Get-ZertoAuthToken or ENV:\ZertoToken')] [Hashtable] $ZertoToken = ( Get-EnvZertoToken ),
#         [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier,
#         [Parameter(Mandatory = $true, HelpMessage = 'vCenter Network Name')] [string] $NetworkName
#     )

#     $ID = Get-ZertoSiteNetwork -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken -ZertoSiteIdentifier $ZertoSiteIdentifier | `
#         Where-Object { $_.VirtualizationNetworkName -eq $NetworkName } | `
#         Select-Object NetworkIdentifier -ExpandProperty NetworkIdentifier

#     if ($ID.Count -gt 1) { Throw "'$NetworkName' returned more than one ID" }
#     if ($ID.Count -eq 0) { Throw "'$NetworkName' was not found" }

#     return $ID.ToString()
# }

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoSiteOrgVCD {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"

    if ([string]::IsNullOrEmpty($ZertoSiteIdentifier)  ) {
        throw "Missing Zerto Site Identifier"
    }

    $FullURL = $baseURL + "virtualizationsites/" + $ZertoSiteIdentifier + "/orgvdcs"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoSiteResourcePool {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = "ID", HelpMessage = 'Zerto Site ResourcePool Identifier')] [string] $ZertoSiteResourcePoolIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"


    if ([string]::IsNullOrEmpty($ZertoSiteIdentifier)  ) {
        throw "Missing Zerto Site Identifier"
    }

    $FullURL = $baseURL + "virtualizationsites/" + $ZertoSiteIdentifier + "/resourcepools"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }

    #Filter by ID if needed
    switch ($PsCmdlet.ParameterSetName) {
        "ID" {
            $Result = $Result | Where-Object { $_.ResourcePoolIdentifier -eq $ZertoSiteResourcePoolIdentifier }
        }
        Default {
        }
    }

    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoSiteVApp {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"


    if ([string]::IsNullOrEmpty($ZertoSiteIdentifier)  ) {
        throw "Missing Zerto Site Identifier"
    }

    $FullURL = $baseURL + "virtualizationsites/" + $ZertoSiteIdentifier + "/vapps"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoSiteVcdVapp {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"

    if ([string]::IsNullOrEmpty($ZertoSiteIdentifier)  ) {
        throw "Missing Zerto Site Identifier"
    }

    $FullURL = $baseURL + "virtualizationsites/" + $ZertoSiteIdentifier + "/vcdvapps"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoSiteVM {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier,
        [Parameter(Mandatory = $false, ParameterSetName = "ID", HelpMessage = 'Zerto Site VM Identifier')] [string] $ZertoSiteVMIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"

    if ([string]::IsNullOrEmpty($ZertoSiteIdentifier)  ) {
        throw "Missing Zerto Site Identifier"
    }

    $FullURL = $baseURL + "virtualizationsites/" + $ZertoSiteIdentifier + "/vms"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }

    #Filter by ID if needed
    switch ($PsCmdlet.ParameterSetName) {
        "ID" {
            $Result = $Result | Where-Object { $_.VmIdentifier -eq $ZertoSiteVMIdentifier }
        }
        Default {
        }
    }

    return $Result
}

# # .ExternalHelp ZertoModule.psm1-help.xml
# Function Get-ZertoSiteVMID {
#     [CmdletBinding()]
#     param(
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
#         [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier,
#         [Parameter(Mandatory = $true, HelpMessage = 'Virtual Machine Name')] [string] $VMName
#     )

#     $ID = Get-ZertoSiteVM -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken -ZertoSiteIdentifier $ZertoSiteIdentifier | `
#         Where-Object { $_.VmName -eq $VMName } | `
#         Select-Object VmIdentifier -ExpandProperty VmIdentifier

#     if ($ID.Count -gt 1) { Throw "'$VMName' returned more than one ID" }
#     if ($ID.Count -eq 0) { Throw "'$VMName' was not found" }

#     return $ID.ToString()
# }

# .ExternalHelp ZertoModule.psm1-help.xml
Function Get-ZertoSiteRepository {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
        [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier
    )

    ## Get Session Configuration
    $ZertoSessionConfig = $global:ZertoSessions[$ZertoSession]
    if (-not $ZertoSessionConfig) {
        Write-Host 'TMSession: [' -NoNewline
        Write-Host $ZertoSession -ForegroundColor Cyan
        Write-Host '] was not Found. Please use the New-ZertoSession command.'
        Throw "Zerto Session Not Found.  Use New-TMSession command before using features."
    }

    #Honor SSL Settings
    if ($ZertoSessionConfig.AllowInsecureSSL) {
        $ZertoCertSettings = @{SkipCertificateCheck = $true }
    }
    else {
        $ZertoCertSettings = @{SkipCertificateCheck = $false }
    }

    $baseURL = "https://" + $ZertoSessionConfig.ZertoServer + ":" + $ZertoSessionConfig.ZertoPort + "/v1/"
    $TypeJSON = "application/json"

    if ([string]::IsNullOrEmpty($ZertoSiteIdentifier)  ) {
        throw "Missing Zerto Site Identifier"
    }

    $FullURL = $baseURL + "virtualizationsites/" + $ZertoSiteIdentifier + "/repositories"
    Write-Verbose $FullURL

    try {
        $RestMethodSplat = @{
            Uri         = $FullURL
            TimeoutSec  = 100
            ContentType = $TypeJSON
            Method      = 'GET'
            WebSession  = $ZertoSessionConfig.ZertoWebSession
        }
        $Result = Invoke-RestMethod @RestMethodSplat @ZertoCertSettings
    }
    catch {
        throw $_.Exception.Message
    }
    return $Result
}

# # .ExternalHelp ZertoModule.psm1-help.xml
# Function Get-ZertoSiteRepositoryID {
#     [CmdletBinding()]
#     param(
#         [Parameter(Mandatory = $false, HelpMessage = 'Zerto Session Name')][String]$ZertoSession = "Default",
#         [Parameter(Mandatory = $true, HelpMessage = 'Zerto Site Identifier')] [string] $ZertoSiteIdentifier,
#         [Parameter(Mandatory = $true, HelpMessage = 'Zerto Backup Repository Name')] [string] $RepositoryName
#     )

#     $ID = Get-ZertoSiteRepository -ZertoServer $ZertoServer -ZertoPort $ZertoPort -ZertoToken $ZertoToken -ZertoSiteIdentifier $ZertoSiteIdentifier | `
#         Where-Object { $_.DisplayName -eq $RepositoryName } | `
#         Select-Object ID -ExpandProperty ID

#     if ($ID.Count -gt 1) { Throw "'$RepositoryName' returned more than one ID" }
#     if ($ID.Count -eq 0) { Throw "'$RepositoryName' was not found" }

#     return $ID.ToString()
# }
#endregion